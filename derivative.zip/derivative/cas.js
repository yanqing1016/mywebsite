/* CAS.js —— 青岩站点符号计算引擎（纯前端，零依赖）
 * 提供：CAS.parse（表达式 → AST）、CAS.simplify、CAS.diff、CAS.integrate、CAS.format
 * 支持：+ - * / ^、隐式乘法（2x、3sin(x)）、sin cos tan cot sec csc asin acos atan ln log sqrt exp、
 *       常量 e / pi、变量 x、有理数精确算术（系数不丢精度）、多项式展开与同类项合并。
 * 积分覆盖：多项式/幂、1/x、e^u、a^u、sin/cos/tan/cot/ln/sqrt/asin/atan 的线性换元 u=kx+b、
 *           分母一次式 → ln、线性 × 可积函数的分部积分。超出范围返回 unsupported。
 */
window.CAS = (function () {
  "use strict";

  /* ---------------- 有理数（精确系数） ---------------- */
  function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { var t = a % b; a = b; b = t; } return a || 1; }
  function R(n, d) {
    if (d === undefined || d === null) d = 1;
    if (!isFinite(n) || !isFinite(d)) throw new Error("数字无效");
    n = Math.round(n); d = Math.round(d);
    if (d === 0) throw new Error("除数为零");
    if (d < 0) { n = -n; d = -d; }
    var g = gcd(n, d);
    return { n: n / g, d: d / g };
  }
  function rAdd(a, b) { return R(a.n * b.d + b.n * a.d, a.d * b.d); }
  function rSub(a, b) { return R(a.n * b.d - b.n * a.d, a.d * b.d); }
  function rMul(a, b) { return R(a.n * b.n, a.d * b.d); }
  function rDiv(a, b) { if (b.n === 0) throw new Error("除数为零"); return R(a.n * b.d, a.d * b.n); }
  function rNeg(a) { return { n: -a.n, d: a.d }; }
  function rRecip(a) { if (a.n === 0) throw new Error("除数为零"); return R(a.d, a.n); }
  function rPow(a, k) {
    if (k < 0) { if (a.n === 0) throw new Error("0 的负次幂"); a = rDiv({ n: 1, d: 1 }, a); k = -k; }
    var n = 1, d = 1;
    for (var i = 0; i < k; i++) { n *= a.n; d *= a.d; }
    return R(n, d);
  }
  function rIsZero(a) { return a.n === 0; }
  function rIsInt(a) { return a.d === 1; }
  function rIsOne(a) { return a.n === 1 && a.d === 1; }
  function rEq(a, b) { return a.n === b.n && a.d === b.d; }

  /* ---------------- 节点构造 ---------------- */
  function N(r) { return { t: "num", r: r }; }
  function NUM(n, d) { return N(R(n, d)); }
  function X() { return { t: "var" }; }
  function E() { return { t: "const", name: "e" }; }
  function PI() { return { t: "const", name: "pi" }; }
  function ADD(a, b) { return { t: "op", o: "+", a: a, b: b }; }
  function SUB(a, b) { return { t: "op", o: "-", a: a, b: b }; }
  function MUL(a, b) { return { t: "op", o: "*", a: a, b: b }; }
  function DIV(a, b) { return { t: "op", o: "/", a: a, b: b }; }
  function POW(a, b) { return { t: "op", o: "^", a: a, b: b }; }
  function NEG(a) { return { t: "neg", a: a }; }
  function FN(f, a) { return { t: "fn", f: f, a: a }; }

  /* ---------------- 词法分析 ---------------- */
  var FUNCS = ["asin", "acos", "atan", "sinh", "cosh", "tanh", "sin", "cos", "tan", "cot", "sec", "csc", "ln", "log", "sqrt", "exp", "abs"];
  var CONSTS = ["pi"];

  function tokenize(src) {
    var s = src.replace(/\s+/g, "")
      .replace(/π/g, "pi").replace(/×/g, "*").replace(/÷/g, "/")
      .replace(/−/g, "-").replace(/\*\*/g, "^").replace(/√/g, "sqrt");
    var toks = [], i = 0;
    while (i < s.length) {
      var c = s[i];
      if (/[0-9.]/.test(c)) {
        var j = i; while (j < s.length && /[0-9.]/.test(s[j])) j++;
        toks.push({ t: "num", v: s.slice(i, j) }); i = j;
      } else if (/[a-zA-Z]/.test(c)) {
        var rest = s.slice(i), matched = null;
        for (var k = 0; k < FUNCS.length; k++) {
          if (rest.slice(0, FUNCS[k].length).toLowerCase() === FUNCS[k]) { matched = FUNCS[k]; break; }
        }
        if (!matched) {
          if (rest.slice(0, 2).toLowerCase() === "pi") matched = "pi";
          else if (c.toLowerCase() === "e") matched = "e";
        }
        if (matched) { toks.push({ t: "name", v: matched }); i += matched.length; }
        else if (c.toLowerCase() === "x") { toks.push({ t: "var", v: "x" }); i += 1; }
        else throw new Error("不支持的符号：" + c + "（目前仅支持变量 x）");
      } else if ("+-*/^()".indexOf(c) >= 0) {
        toks.push({ t: c }); i += 1;
      } else throw new Error("无法识别的字符：" + c);
    }
    return toks;
  }

  /* ---------------- 语法分析（递归下降 + 隐式乘法） ---------------- */
  function parse(src) {
    var toks = tokenize(src), pos = 0;
    function peek() { return toks[pos] || null; }
    function next() { return toks[pos++]; }
    function expect(t) {
      var tok = next();
      if (!tok || tok.t !== t) throw new Error("表达式格式不完整（缺少 " + (t === ")" ? "右括号" : t) + "）");
    }

    function parseExpr() {
      var node = parseTerm();
      while (peek() && (peek().t === "+" || peek().t === "-")) {
        var op = next().t;
        node = op === "+" ? ADD(node, parseTerm()) : SUB(node, parseTerm());
      }
      return node;
    }
    function parseTerm() {
      var node = parseUnary();
      for (;;) {
        var p = peek();
        if (!p) break;
        if (p.t === "*") { next(); node = MUL(node, parseUnary()); }
        else if (p.t === "/") { next(); node = DIV(node, parseUnary()); }
        else if (p.t === "num" || p.t === "var" || p.t === "name" || p.t === "(") {
          node = MUL(node, parseUnary());       // 隐式乘法：2x、3sin(x)、(x+1)(x-1)
        } else break;
      }
      return node;
    }
    function parseUnary() {
      var p = peek();
      if (p && p.t === "-") { next(); return NEG(parseUnary()); }
      if (p && p.t === "+") { next(); return parseUnary(); }
      return parsePower();
    }
    function parsePower() {
      var base = parsePrimary();
      var p = peek();
      if (p && p.t === "^") {
        next();
        var exp = parseUnary();   // 右结合，允许 x^-2
        return POW(base, exp);
      }
      return base;
    }
    function parsePrimary() {
      var p = peek();
      if (!p) throw new Error("表达式意外结束");
      if (p.t === "num") {
        next();
        var parts = p.v.split(".");
        var r = parts.length === 2 ? R(parseInt(parts[0] || "0", 10) * Math.pow(10, parts[1].length) + parseInt(parts[1] || "0", 10), Math.pow(10, parts[1].length))
                                   : R(parseInt(p.v, 10));
        return N(r);
      }
      if (p.t === "var") { next(); return X(); }
      if (p.t === "name") {
        next();
        var v = p.v;
        if (v === "e") return E();
        if (v === "pi") return PI();
        // 函数：sin(...) 或 sinx（省略括号）
        var arg;
        if (peek() && peek().t === "(") { next(); arg = parseExpr(); expect(")"); }
        else arg = parsePower();
        if (v === "sqrt") return POW(arg, N(R(1, 2)));   // sqrt(u) = u^(1/2)
        return FN(v, arg);
      }
      if (p.t === "(") { next(); var node = parseExpr(); expect(")"); return node; }
      throw new Error("无法识别的写法：" + (p.v || p.t));
    }

    var ast = parseExpr();
    if (pos < toks.length) throw new Error("表达式末尾有多余内容");
    return simplify(ast);
  }

  /* ---------------- 化简 ---------------- */
  function isNum(n) { return n.t === "num"; }
  function rOf(n) { return n.r; }

  function toPoly(node) {
    // 返回 Map("exp" → R) 或 null（不是多项式结构）
    var p = toPolyRaw(node);
    return p;
  }
  function toPolyRaw(node) {
    if (node.t === "num") { var m0 = new Map(); if (!rIsZero(node.r)) m0.set(0, node.r); return m0; }
    if (node.t === "var") { var m1 = new Map(); m1.set(1, R(1)); return m1; }
    if (node.t === "const") return null;
    if (node.t === "neg") {
      var pn = toPolyRaw(node.a); if (!pn) return null;
      pn.forEach(function (v, k) { pn.set(k, rNeg(v)); });
      return pn;
    }
    if (node.t === "op") {
      if (node.o === "+" || node.o === "-") {
        var pa = toPolyRaw(node.a), pb = toPolyRaw(node.b);
        if (!pa || !pb) return null;
        var out = new Map();
        pa.forEach(function (v, k) { out.set(k, v); });
        pb.forEach(function (v, k) {
          var cur = out.get(k) || R(0);
          out.set(k, node.o === "+" ? rAdd(cur, v) : rSub(cur, v));
        });
        return clean(out);
      }
      if (node.o === "*") {
        var ma = toPolyRaw(node.a), mb = toPolyRaw(node.b);
        if (!ma || !mb) return null;
        return polyMul(ma, mb);
      }
      if (node.o === "/") {
        var da = toPolyRaw(node.a), db = toPolyRaw(node.b);
        if (!da || !db) return null;
        if (db.size !== 1) return null;
        var exp = Number(db.keys().next().value), coef = db.get(exp);
        if (exp < -8 || exp > 8) return null;
        var outd = new Map();
        da.forEach(function (v, k) {
          var ne = k - exp;
          if (Math.abs(ne) > 12) { outd = null; return; }
          outd.set(ne, rDiv(v, coef));
        });
        return outd === null ? null : clean(outd);
      }
      if (node.o === "^") {
        if (!isNum(node.b) || !rIsInt(node.b.r)) return null;
        var k = node.b.r.n;
        if (Math.abs(k) > 8) return null;
        var base = toPolyRaw(node.a);
        if (!base) return null;
        if (k < 0) {
          if (base.size !== 1) return null;
          var e0 = Number(base.keys().next().value), c0 = base.get(e0);
          if (rIsZero(c0)) return null;
          var inv = new Map(); inv.set(-e0, rPow(c0, k));
          return clean(inv);
        }
        var acc = new Map(); acc.set(0, R(1));
        for (var i = 0; i < k; i++) acc = polyMul(acc, base);
        return clean(acc);
      }
    }
    if (node.t === "fn") {
      // sqrt(u)：u 为单项式且系数为完全平方时视为多项式
      if (node.f === "sqrt") {
        var inner = toPolyRaw(node.a);
        if (!inner || inner.size !== 1) return null;
        var e1 = Number(inner.keys().next().value), c1 = inner.get(e1);
        var sqN = c1.n * c1.d;
        var rt = Math.round(Math.sqrt(sqN));
        if (rt * rt !== sqN || (c1.d !== 1 && !Number.isInteger(Math.sqrt(c1.d)))) return null;
        var halfExp = e1 / 2;
        if (Math.abs(halfExp) > 8) return null;
        var outm = new Map();
        outm.set(halfExp, R(Math.sqrt(c1.n), c1.d === 1 ? 1 : Math.sqrt(c1.d)));
        return clean(outm);
      }
    }
    return null;
  }
  function polyMul(a, b) {
    var out = new Map();
    a.forEach(function (va, ka) {
      b.forEach(function (vb, kb) {
        var k = ka + kb;
        if (Math.abs(k) > 16) throw new Error("指数过大");
        var cur = out.get(k) || R(0);
        out.set(k, rAdd(cur, rMul(va, vb)));
      });
    });
    return clean(out);
  }
  function clean(m) {
    [...m.keys()].forEach(function (k) { if (rIsZero(m.get(k))) m.delete(k); });
    return m;
  }

  function polyToExpr(m) {
    var exps = [...m.keys()].filter(function (k) { return !rIsZero(m.get(k)); })
      .map(Number).sort(function (a, b) { return b - a; });
    if (!exps.length) return N(R(0));
    var node = null;
    exps.forEach(function (k) {
      var c = m.get(k);
      var neg = c.n < 0;
      var term = termNode(neg ? rNeg(c) : c, k);
      if (node === null) node = neg ? NEG(term) : term;
      else node = ADD(node, neg ? NEG(term) : term);
    });
    return node;
  }
  function termNode(c, k) {
    if (k === 0) return N(c);
    var xp = k === 1 ? X() : POW(X(), N(R(k)));
    if (rIsOne(c)) return xp;
    return MUL(N(c), xp);
  }

  function simplify(node) {
    if (node.t === "neg") {
      var a = simplify(node.a);
      if (a.t === "num") return N(rNeg(a.r));
      if (a.t === "neg") return a.a;
      if (a.t === "op" && a.o === "*") {
        if (a.a.t === "num") return simplify(MUL(N(rNeg(a.a.r)), a.b));
      }
      return { t: "neg", a: a };
    }
    if (node.t === "op") {
      var A = simplify(node.a), B = simplify(node.b);
      if (node.o === "+") {
        if (isNum(A) && isNum(B)) return N(rAdd(A.r, B.r));
        if (isNum(A) && rIsZero(A.r)) return B;
        if (isNum(B) && rIsZero(B.r)) return A;
        var p = polyAddMaybe(A, toPolyRaw(B));
        if (p) return p;
        return ADD(A, B);
      }
      if (node.o === "-") {
        if (isNum(A) && isNum(B)) return N(rSub(A.r, B.r));
        if (isNum(B) && rIsZero(B.r)) return A;
        if (isNum(A) && rIsZero(A.r)) return simplify(NEG(B));
        var ps = polyAddMaybe(A, polyNegMaybe(B));
        if (ps) return ps;
        return SUB(A, B);
      }
      if (node.o === "*") {
        if (isNum(A) && isNum(B)) return N(rMul(A.r, B.r));
        if (isNum(A) && rIsZero(A.r)) return N(R(0));
        if (isNum(B) && rIsZero(B.r)) return N(R(0));
        if (isNum(A) && rIsOne(A.r)) return B;
        if (isNum(B) && rIsOne(B.r)) return A;
        if (isNum(A) && A.r.n < 0) return simplify(NEG(MUL(N(rNeg(A.r)), B)));
        if (isNum(B) && B.r.n < 0) return simplify(NEG(MUL(A, N(rNeg(B.r)))));
        var pm = polyMulMaybe(A, B);
        if (pm) return pm;
        return MUL(A, B);
      }
      if (node.o === "/") {
        if (isNum(A) && isNum(B)) { try { return N(rDiv(A.r, B.r)); } catch (e) { throw new Error("除数为零"); } }
        if (isNum(A) && rIsZero(A.r)) return N(R(0));
        if (isNum(B) && rIsOne(B.r)) return A;
        if (isNum(B) && !rIsOne(B.r) && B.r.d !== 1) return simplify(MUL(A, N(rRecip(B.r))));
        if (A.t === "var" && B.t === "var") return N(R(1));
        return DIV(A, B);
      }
      if (node.o === "^") {
        if (isNum(A) && isNum(B) && rIsInt(B.r)) { try { return N(rPow(A.r, B.r.n)); } catch (e) { /* fall through */ } }
        if (isNum(B) && rIsZero(B.r)) return N(R(1));
        if (isNum(B) && rIsOne(B.r)) return A;
        if (isNum(A) && rIsOne(A.r)) return N(R(1));
        if (isNum(A) && rIsZero(A.r)) return N(R(0));
        return POW(A, B);
      }
    }
    if (node.t === "fn") {
      var arg = simplify(node.a);
      if (arg.t === "num") {
        var r = arg.r;
        if (node.f === "ln" && rIsOne(r)) return N(R(0));
        if (node.f === "log" && rIsOne(r)) return N(R(0));
        if (node.f === "sqrt" && rIsOne(r)) return N(R(1));
        if (node.f === "sin" && rIsZero(r)) return N(R(0));
        if (node.f === "cos" && rIsZero(r)) return N(R(1));
        if (node.f === "tan" && rIsZero(r)) return N(R(0));
      }
      return FN(node.f, arg);
    }
    return node;
  }

  function polyNegMaybe(node) {
    var p = toPolyRaw(node);
    if (!p) return null;
    p.forEach(function (v, k) { p.set(k, rNeg(v)); });
    return clean(p);
  }
  function polyAddMaybe(A, B) {
    if (!A || !B) return null;
    var pa = toPolyRaw(A), pb = B;
    if (!pa || !pb) return null;
    var out = new Map();
    pa.forEach(function (v, k) { out.set(k, v); });
    pb.forEach(function (v, k) { out.set(k, rAdd(out.get(k) || R(0), v)); });
    var c = clean(out);
    if (!c.size) return N(R(0));
    return polyToExpr(c);
  }
  function polyMulMaybe(A, B) {
    var pa = toPolyRaw(A), pb = toPolyRaw(B);
    if (!pa || !pb) return null;
    var c;
    try { c = clean(polyMul(pa, pb)); } catch (e) { return null; }
    if (!c.size) return N(R(0));
    return polyToExpr(c);
  }
  function simplifyNums(node) { return simplify(node); }

  /* ---------------- 求导 ---------------- */
  function isFreeOfX(node) {
    if (node.t === "var") return false;
    if (node.t === "num" || node.t === "const") return true;
    if (node.t === "neg") return isFreeOfX(node.a);
    if (node.t === "op") return isFreeOfX(node.a) && isFreeOfX(node.b);
    if (node.t === "fn") return isFreeOfX(node.a);
    return true;
  }

  function diff(node) {
    if (node.t === "num" || node.t === "const") return N(R(0));
    if (node.t === "var") return N(R(1));
    if (node.t === "neg") return simplify(NEG(diff(node.a)));
    if (node.t === "op") {
      if (node.o === "+" || node.o === "-") {
        var d = node.o === "+" ? ADD(diff(node.a), diff(node.b)) : SUB(diff(node.a), diff(node.b));
        return simplify(d);
      }
      if (node.o === "*") {
        return simplify(ADD(MUL(diff(node.a), node.b), MUL(node.a, diff(node.b))));
      }
      if (node.o === "/") {
        return simplify(DIV(SUB(MUL(diff(node.a), node.b), MUL(node.a, diff(node.b))), POW(node.b, N(R(2)))));
      }
      if (node.o === "^") {
        var u = node.a, v = node.b;
        if (u.t === "const" && u.name === "e") return simplify(MUL(POW(E(), v), diff(v)));
        if (isNum(v) && rIsInt(v.r)) {
          var k = v.r.n;
          var newExp = N(R(k - 1));
          var factor = N(R(k));
          return simplify(MUL(MUL(factor, POW(u, newExp)), diff(u)));
        }
        if (isFreeOfX(v)) {
          return simplify(MUL(POW(u, v), MUL(diff(v), FN("ln", u))));
        }
        // 一般 u^v：u^v · (v'·ln u + v·u'/u)
        return simplify(MUL(POW(u, v), simplify(ADD(MUL(diff(v), FN("ln", u)), DIV(MUL(v, diff(u)), u)))));
      }
    }
    if (node.t === "fn") {
      var u = node.a, du = diff(u);
      switch (node.f) {
        case "sin": return simplify(MUL(FN("cos", u), du));
        case "cos": return simplify(NEG(MUL(FN("sin", u), du)));
        case "tan": return simplify(DIV(du, POW(FN("cos", u), N(R(2)))));
        case "cot": return simplify(NEG(DIV(du, POW(FN("sin", u), N(R(2))))));
        case "sec": return simplify(MUL(MUL(FN("sec", u), FN("tan", u)), du));
        case "csc": return simplify(NEG(MUL(MUL(FN("csc", u), FN("cot", u)), du)));
        case "ln": return simplify(DIV(du, u));
        case "log": return simplify(DIV(du, MUL(u, FN("ln", N(R(10))))));
        case "sqrt": return simplify(DIV(du, MUL(N(R(2)), FN("sqrt", u))));
        case "exp": return simplify(MUL(FN("exp", u), du));
        case "asin": return simplify(DIV(du, FN("sqrt", SUB(N(R(1)), POW(u, N(R(2)))))));
        case "acos": return simplify(NEG(DIV(du, FN("sqrt", SUB(N(R(1)), POW(u, N(R(2))))))));
        case "atan": return simplify(DIV(du, ADD(N(R(1)), POW(u, N(R(2))))));
        case "abs": throw new Error("暂不支持对绝对值函数求导");
      }
      throw new Error("暂不支持的函数：" + node.f);
    }
    throw new Error("无法对该表达式求导");
  }

  /* ---------------- 积分 ---------------- */
  function linK(node) {
    // u = kx + b → {k, b}（有理数），否则 null
    var p = toPolyRaw(node);
    if (!p || p.size > 2) return null;
    var k = p.get(1), b = p.get(0) || R(0);
    if (!k || rIsZero(k)) return null;
    return { k: k, b: b };
  }
  function hasX(node) { return !isFreeOfX(node); }

  function integrate(node, allowParts) {
    if (allowParts === undefined) allowParts = true;

    // 常量（不含 x）
    if (isFreeOfX(node)) return MUL(node, X());

    if (node.t === "var") return DIV(POW(X(), N(R(2))), N(R(2)));
    if (node.t === "neg") {
      var inner = integrate(node.a, false);
      return inner ? simplify(NEG(inner)) : null;
    }
    if (node.t === "op") {
      if (node.o === "+" || node.o === "-") {
        var ia = integrate(node.a, allowParts), ib = integrate(node.b, allowParts);
        if (!ia || !ib) return null;
        return simplify(node.o === "+" ? ADD(ia, ib) : SUB(ia, ib));
      }
      if (node.o === "*") {
        var aFree = isFreeOfX(node.a), bFree = isFreeOfX(node.b);
        if (aFree) { var ib2 = integrate(node.b, allowParts); return ib2 ? simplify(MUL(node.a, ib2)) : null; }
        if (bFree) { var ia2 = integrate(node.a, allowParts); return ia2 ? simplify(MUL(node.b, ia2)) : null; }
        // 两个都含 x：多项式乘积展开
        var prod = polyMulMaybe(node.a, node.b);
        if (prod) { var ip = integrate(prod, false); if (ip) return ip; }
        // 分部积分：u = kx+b（线性）× g（可积）
        if (allowParts) {
          var lin = linK(node.a) ? { u: node.a, g: node.b } : (linK(node.b) ? { u: node.b, g: node.a } : null);
          if (lin) {
            var lk = linK(lin.u).k;
            var F = integrate(lin.g, false);
            if (F) {
              var inner = integrate(F, false);
              if (inner) return simplify(SUB(MUL(lin.u, F), MUL(N(lk), inner)));
            }
          }
        }
        return null;
      }
      if (node.o === "/") {
        var numHasX = hasX(node.a), denHasX = hasX(node.b);
        if (!denHasX) {
          // 分母为多项式（一次 → ln；单项式 → 幂）
          var db = toPolyRaw(node.b);
          if (db && db.size === 1) {
            var dexp = Number(db.keys().next().value), dcoef = db.get(dexp);
            var iNum = integrate(node.a, false);
            if (!iNum) return null;
            if (dexp === 0) return simplify(DIV(iNum, node.b));
            if (dexp === 1) {
              var kb = linK(node.b);
              return simplify(DIV(FN("ln", FN("abs", node.b)), N(kb.k)));
            }
            // 分母 x^k（k≥2）：x^(-k)
            var newNode = MUL(node.a, POW(X(), N(R(-dexp))));
            var iRes = integrate(newNode, false);
            return iRes ? simplify(DIV(iRes, dcoef)) : null;
          }
          return null;
        }
        if (!numHasX) {
          // 分子为常数：1/u（u 一次）→ ln|u|/k；u 单项式 x^k → 幂
          var ub = linK(node.b);
          if (ub) return simplify(DIV(FN("ln", FN("abs", node.b)), N(ub.k)));
          var pb = toPolyRaw(node.b);
          if (pb && pb.size === 1) {
            var be = Number(pb.keys().next().value), bc = pb.get(be);
            var nodeAlt = MUL(node.a, POW(X(), N(R(-be))));
            var iAlt = integrate(simplify(DIV(nodeAlt, bc)) , false);
            return iAlt ? simplify(DIV(iAlt, bc)) : null;
          }
          // 1/(1+x^2) → atan(x)；1/sqrt(1-x^2) → asin(x)
          if (node.b.t === "op" && node.b.o === "+" &&
              isNum(node.b.a) && rIsOne(node.b.a.r) &&
              node.b.b.t === "op" && node.b.b.o === "^" &&
              node.b.b.a.t === "var" && isNum(node.b.b.b) && rEq(node.b.b.b.r, R(2))) {
            return FN("atan", X());
          }
          return null;
        }
        return null;
      }
      if (node.o === "^") {
        var base = node.a, exp = node.b;
        var baseFree = isFreeOfX(base), expFree = isFreeOfX(exp);
        if (baseFree && expFree) return MUL(node, X());
        if (baseFree && !expFree) {
          // a^u（a 常量）：u 线性 → a^u / (k·ln a)；e^u → e^u / k
          var lk2 = linK(exp);
          if (!lk2) return null;
          var denom = base.t === "const" && base.name === "e"
            ? N(lk2.k)
            : MUL(N(lk2.k), FN("ln", base));
          return simplify(DIV(POW(base, exp), denom));
        }
        if (!baseFree && expFree) {
          // base = x（或单项式/线性），指数为有理常数
          if (isNum(exp) && rEq(exp.r, R(-1))) return FN("ln", FN("abs", base));
          if (base.t === "var") {
            var newExp = rAdd(exp.r, R(1));
            if (rIsZero(newExp)) return FN("ln", FN("abs", X()));
            return simplify(DIV(POW(X(), N(newExp)), N(newExp)));
          }
          var lu = linK(base);
          if (lu && isNum(exp)) {
            var ne = rAdd(exp.r, R(1));
            if (rIsZero(ne)) return simplify(DIV(FN("ln", FN("abs", base)), N(lu.k)));
            return simplify(DIV(POW(base, N(ne)), MUL(N(ne), N(lu.k))));
          }
          var pb2 = toPolyRaw(base);
          if (pb2 && isNum(exp) && rIsInt(exp.r)) {
            var alt = POW(X(), exp);
            var iP = integrate(simplify(alt), false);
            return iP || null;
          }
          return null;
        }
        return null; // x^x 等超出范围
      }
    }
    if (node.t === "fn") {
      var u = node.a;
      if (isFreeOfX(u)) return MUL(node, X());
      var lk3 = linK(u);
      if (!lk3) return null;
      var k3 = N(lk3.k);
      var uNode = u;
      switch (node.f) {
        case "sin": return simplify(DIV(NEG(FN("cos", uNode)), k3));
        case "cos": return simplify(DIV(FN("sin", uNode), k3));
        case "tan": return simplify(DIV(NEG(FN("ln", FN("abs", FN("cos", uNode)))), k3));
        case "cot": return simplify(DIV(FN("ln", FN("abs", FN("sin", uNode))), k3));
        case "ln": return simplify(DIV(SUB(MUL(uNode, FN("ln", uNode)), uNode), k3));
        case "log": return simplify(DIV(SUB(MUL(uNode, FN("ln", uNode)), uNode), MUL(k3, FN("ln", N(R(10))))));
        case "sqrt": {
          var half = N(R(1, 2));
          var ne3 = rAdd(half.r, R(1));
          return simplify(DIV(POW(uNode, N(ne3)), MUL(N(ne3), k3)));
        }
        case "exp": return simplify(DIV(FN("exp", uNode), k3));
        case "asin": return simplify(DIV(ADD(MUL(uNode, FN("asin", uNode)), FN("sqrt", SUB(N(R(1)), POW(uNode, N(R(2)))))), k3));
        case "atan": return simplify(DIV(SUB(MUL(uNode, FN("atan", uNode)), DIV(FN("ln", ADD(N(R(1)), POW(uNode, N(R(2))))), N(R(2)))), k3));
      }
      return null;
    }
    return null;
  }

  /* ---------------- 格式化 ---------------- */
  var SUP = { "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹" };
  function fmtR(r) {
    return r.d === 1 ? String(r.n) : r.n + "/" + r.d;
  }
  function fmt(node, parentPrec) {
    var prec = 0, s = "";
    switch (node.t) {
      case "num":
        s = fmtR(node.r);
        prec = node.r.n < 0 ? 1 : 5;
        break;
      case "const": s = node.name; prec = 5; break;
      case "constC": s = "C"; prec = 5; break;
      case "var": s = "x"; prec = 5; break;
      case "neg":
        s = "-" + fmt(node.a, 3);
        prec = 3;
        break;
      case "op":
        if (node.o === "+" || node.o === "-") {
          prec = 1;
          var right = fmt(node.b, 1);
          if (node.o === "-" && /^-/.test(right)) {
            right = right.slice(1);
            s = fmt(node.a, 1) + " - " + right;
          } else s = fmt(node.a, 1) + (node.o === "+" ? " + " : " - ") + right;
        } else if (node.o === "*") {
          prec = 2;
          s = fmt(node.a, 2) + "·" + fmt(node.b, 2);
        } else if (node.o === "/") {
          prec = 2;
          s = fmt(node.a, 2) + "/" + fmt(node.b, 3);
        } else if (node.o === "^") {
          prec = 4;
          var baseS = fmt(node.a, 4);
          if (node.b.t === "num" && rIsInt(node.b.r) && SUP[String(node.b.r.n)]) {
            s = baseS + SUP[String(node.b.r.n)];
          } else s = baseS + "^(" + fmt(node.b, 0) + ")";
        }
        break;
      case "fn":
        prec = 5;
        var argS = fmt(node.a, 0);
        s = node.f === "abs" ? "|" + argS + "|" : node.f + "(" + argS + ")";
        break;
    }
    if (parentPrec !== undefined && prec < parentPrec && !(parentPrec === 2 && prec === 2)) {
      // 乘除同级从左到右，不需要括号
      if (!(parentPrec === 2 && node.t === "op" && (node.o === "*" || node.o === "/"))) {
        return "(" + s + ")";
      }
    }
    return s;
  }

  return {
    parse: function (s) { return parse(s); },
    simplify: simplify,
    diff: function (s) {
      var ast = typeof s === "string" ? parse(s) : s;
      return simplify(diff(ast));
    },
    integrate: function (s) {
      var ast = typeof s === "string" ? parse(s) : s;
      var res = integrate(simplify(ast), true);
      if (!res) throw new Error("暂不支持这个形式的积分（可尝试化简后再试）");
      return simplify(ADD(res, { t: "constC" }));
    },
    format: function (node) { return fmt(simplify(node), undefined).replace(/\+ C/g, "+ C"); },
    addC: function (node) { return simplify(ADD(node, { t: "constC" })); }
  };
})();
