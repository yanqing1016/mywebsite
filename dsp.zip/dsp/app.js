/* 戴森球计划 产线计算器 */
'use strict';

const D = window.APP_DATA;
const $ = (id) => document.getElementById(id);
const ZOOM_MIN = 0.05, ZOOM_MAX = 2.5;
const FRAC_FLOW = 1800; // 分馏塔氢流速 items/min（未堆叠极速传送带）

// ---- State ----
const state = {
  itemId: null,
  rate: 60,
  treatOreAsRaw: true,
  prolifTier: 'none',     // 全局默认等级: none | Mk.I | Mk.II | Mk.III
  prolifMode: 'speed',    // 全局默认模式: speed | extra
  defaultTier: '标准',     // 基础 | 标准 | 进阶 | 极致
  recipeChoice: {},
  buildingChoice: {},     // itemId -> buildingId
  prolifSel: {},          // itemId -> { tier, mode } | 未设置=不使用
  hasComputed: false,     // 只有点击「计算产线」后才展示流程
  pickerOpen: false,      // 配方选择抽屉默认收起
  tree: null,
  zoom: 1, panX: 0, panY: 0,
  viewMode: 'tree',
};

// ---- Utilities ----
function fmt(n) {
  if (n === 0) return '0';
  if (Math.abs(n) < 0.001) return n.toExponential(2);
  const r = Math.round(n * 1000) / 1000;
  return Number.isInteger(r) ? r.toString() : r.toFixed(3).replace(/\.?0+$/, '');
}
function itemZh(id) { return D.items[id]?.zh || id; }
function itemImg(id) { return D.items[id]?.img || ''; }
function isFluid(id) { return !!D.items[id]?.isFluid; }
function isAlwaysRaw(id) { return D.alwaysRaw.includes(id); }
function isTerminalRaw(id) {
  if (isAlwaysRaw(id)) return true;
  if (state.treatOreAsRaw && D.rawResources.includes(id)) return true;
  return false;
}
function buildingInfo(id) {
  return D.buildings[id] || { id, zh: id, name: id, img: '', power: 0, speed: 1, cat: '', slots: 0 };
}
function recipesForItem(itemId) {
  const ids = D.itemToRecipes[itemId] || [];
  const out = [];
  for (const id of ids) { const r = D.recipes[id]; if (r) out.push(r); }
  return out;
}
function defaultRecipe(itemId) {
  if (isTerminalRaw(itemId)) return '__raw__';
  const list = recipesForItem(itemId);
  if (!list.length) return '__raw__';
  return list[0].id;
}
const TIER_BUILDINGS = {
  '冶炼设备': { '基础':'电弧熔炉','标准':'电弧熔炉','进阶':'位面熔炉','极致':'负熵熔炉' },
  '制造台':   { '基础':'制造台Mk.I','标准':'制造台Mk.II','进阶':'制造台Mk.III','极致':'重组式制造台' },
  '化工设备': { '基础':'化工厂','标准':'化工厂','进阶':'量子化工厂','极致':'量子化工厂' },
  '精炼设备': { '基础':'原油精炼厂','标准':'原油精炼厂','进阶':'原油精炼厂','极致':'原油精炼厂' },
  '粒子对撞机': { '基础':'微型粒子对撞机','标准':'微型粒子对撞机','进阶':'微型粒子对撞机','极致':'微型粒子对撞机' },
  '科研设备': { '基础':'矩阵研究站','标准':'矩阵研究站','进阶':'自演化研究站','极致':'自演化研究站' },
  '分馏塔':   { '基础':'分馏塔','标准':'分馏塔','进阶':'分馏塔','极致':'分馏塔' },
  '能量枢纽': { '基础':'能量枢纽','标准':'能量枢纽','进阶':'能量枢纽','极致':'能量枢纽' },
};
function defaultBuildingFor(category) {
  return (TIER_BUILDINGS[category] && TIER_BUILDINGS[category][state.defaultTier]) || category;
}
function chosenBuilding(itemId, recipeId) {
  if (recipeId === '__raw__') return null;
  const r = D.recipes[recipeId];
  if (!r) return null;
  if (r.isFractionator) return '分馏塔';
  if (r.machine === '能量枢纽') return '能量枢纽';
  return state.buildingChoice[itemId] || defaultBuildingFor(r.machine);
}
function isProlifOn(itemId, recipe) {
  if (!recipe || !recipe.prolif) return false;
  return !!state.prolifSel[itemId];
}

// ---- 产物级增产剂选择（无 / Mk.I / Mk.II / Mk.III + 加速/增产，像设备选择一样逐产物可选） ----
function getProlifSel(itemId) { return state.prolifSel[itemId] || null; }
function setProlifSel(itemId, sel) {
  if (sel) state.prolifSel[itemId] = sel;
  else delete state.prolifSel[itemId];
}
function defaultProlifTier() { return state.prolifTier !== 'none' ? state.prolifTier : 'Mk.I'; }
function prolifSelHTML(itemId, on, tier, mode) {
  const effMode = mode || state.prolifMode;
  const tiers = ['Mk.I', 'Mk.II', 'Mk.III'];
  const tierBtns = tiers.map(t =>
    `<button type="button" class="ps-btn ps-tier${on && tier === t ? ' active' : ''}" data-item="${itemId}" data-tier="${t}" title="使用增产剂 ${t}">${t.replace('Mk.', '')}</button>`).join('');
  return `<span class="prolif-sel${on ? ' on' : ''}" data-item="${itemId}">
    <button type="button" class="ps-btn ps-off${on ? '' : ' active'}" data-item="${itemId}" title="不使用增产剂">无</button>
    ${tierBtns}
    <button type="button" class="ps-btn ps-mode${on ? ' active' : ''}" data-item="${itemId}" title="切换 加速生产 / 额外产出">${effMode === 'extra' ? '增产' : '加速'}</button>
  </span>`;
}
function handleProlifSelClick(btn) {
  const itemId = btn.dataset.item;
  const chosen = state.recipeChoice[itemId] || defaultRecipe(itemId);
  const r = D.recipes[chosen];
  if (!r || !(r.prolif || r.isFractionator)) return;
  const cur = getProlifSel(itemId);
  if (btn.classList.contains('ps-off')) {
    setProlifSel(itemId, null);
  } else if (btn.classList.contains('ps-mode')) {
    const newMode = cur ? (cur.mode === 'speed' ? 'extra' : 'speed') : state.prolifMode;
    setProlifSel(itemId, { tier: cur ? cur.tier : defaultProlifTier(), mode: newMode });
  } else {
    const tier = btn.dataset.tier;
    if (cur && cur.tier === tier) return; // 重复点击同一等级不变化
    setProlifSel(itemId, { tier, mode: cur ? cur.mode : state.prolifMode });
  }
  recomputeAndRender(true);
}
// 树节点上的设备切换按钮（多级设备类别才显示）
function bldRowHTML(n) {
  const r = D.recipes[n.recipeId];
  if (!r || r.isFractionator || r.machine === '能量枢纽') return '';
  const cats = D.categoryOrder[r.machine] || [];
  if (cats.length <= 1) return '';
  return `<div class="node-blds">` + cats.map(bId => {
    const bi = buildingInfo(bId);
    return `<button type="button" class="node-bld-btn${bId === n.buildingId ? ' active' : ''}" data-item="${n.itemId}" data-bld="${bId}" title="${bi.zh} ${fmt(bi.speed)}x · ${bi.power}MW"><img src="${bi.img || ''}" alt="${bi.zh}" onerror="this.style.visibility='hidden'"/></button>`;
  }).join('') + `</div>`;
}

// ---- Search / Combobox ----
const searchIndex = Object.values(D.items).map(i => ({
  id: i.id, zh: i.zh, img: i.img,
})).sort((a, b) => a.zh.localeCompare(b.zh, 'zh-Hans-CN'));

function renderDropdown(query) {
  const q = query.trim().toLowerCase();
  const filtered = searchIndex.filter(i => !q || i.zh.toLowerCase().includes(q) || i.id.toLowerCase().includes(q)).slice(0, 90);
  const dd = $('itemDropdown');
  if (!filtered.length) {
    dd.innerHTML = '<div class="drop-item"><span style="color:var(--muted)">无匹配项</span></div>';
  } else {
    dd.innerHTML = filtered.map(i => `
      <div class="drop-item" data-id="${i.id}">
        <img src="${i.img || ''}" alt="" loading="lazy" onerror="this.style.visibility='hidden'"/>
        <span class="zh">${i.zh}</span>
        <button type="button" class="info-btn" data-info="${i.id}" title="查看物品详情">ⓘ</button>
      </div>`).join('');
  }
  dd.classList.remove('hidden');
}
function pickItem(id) {
  state.itemId = id;
  state.recipeChoice = {};
  state.buildingChoice = {};
  state.prolifSel = {};
  state.tree = null;
  state.hasComputed = false;
  const it = D.items[id];
  const el = $('selectedItem');
  el.classList.remove('hidden');
  el.innerHTML = `<img src="${it.img || ''}" alt="" onerror="this.style.visibility='hidden'"/><div class="info"><span class="zh">${it.zh}</span></div><button type="button" class="info-btn" data-info="${id}">详情 ⓘ</button>`;
  $('itemSearch').value = it.zh;
  $('itemDropdown').classList.add('hidden');
  $('recipePicker').innerHTML = '';
  $('nodes').innerHTML = ''; $('edges').innerHTML = '';
  resetViewToTree();
  $('summary').textContent = `已选择「${it.zh}」，点击「计算产线」生成流程`;
  showEmpty(`已选择「${escapeHtml(it.zh)}」<br/>点击左侧「计算产线」按钮生成流程图`);
}
function resetViewToTree() {
  state.viewMode = 'tree';
  $('canvasScroll').style.display = '';
  $('tableContainer').style.display = 'none';
  $('tableContainer').innerHTML = '';
  ['zoomOut', 'zoomReset', 'zoomIn'].forEach(id => $(id).style.display = '');
  document.querySelectorAll('.view-btn').forEach(b => b.classList.toggle('active', b.dataset.view === 'tree'));
}

// ---- BOM calculation ----
let nodeCounter = 0;
function calcTree(itemId, rateNeeded, depth = 0, visited = new Set()) {
  const nodeId = 'n' + (nodeCounter++);
  if (visited.has(itemId)) {
    return { id: nodeId, itemId, rateNeeded, recipeId: '__raw__', isRaw: true, children: [], depth };
  }
  const chosen = state.recipeChoice[itemId] || defaultRecipe(itemId);
  if (chosen === '__raw__') {
    return { id: nodeId, itemId, rateNeeded, recipeId: '__raw__', isRaw: true, children: [], depth };
  }
  const r = D.recipes[chosen];
  if (!r) {
    return { id: nodeId, itemId, rateNeeded, recipeId: '__raw__', isRaw: true, children: [], depth };
  }
  const nextVisited = new Set(visited);
  nextVisited.add(itemId);

  // 分馏塔特殊处理（增产剂可提升转化率，故不依赖 r.prolif 标记）
  if (r.isFractionator) {
    const bId = '分馏塔';
    const b = buildingInfo(bId);
    const sel = getProlifSel(itemId);
    const prolifOn = !!sel;
    const tier = prolifOn ? D.prolif[sel.tier] : null;
    const conversion = 0.01 * (prolifOn ? (1 + tier.extra) : 1);
    const perTower = FRAC_FLOW * conversion;
    const machineCount = rateNeeded / perTower;
    const powerMult = prolifOn ? (1 + tier.power) : 1;
    const powerPerMachine = b.power * powerMult;
    const totalPower = powerPerMachine * machineCount;
    const hInput = rateNeeded; // 净消耗（氢循环，转化部分=重氢产量）
    const children = [calcTree('氢', hInput, depth + 1, nextVisited)];
    return {
      id: nodeId, itemId, rateNeeded, recipeId: chosen, isRaw: false, isFractionator: true,
      machineCount, conversion, powerPerMachine, totalPower, byproducts: [], children, depth,
      prolifOn, prolifTier: prolifOn ? sel.tier : null, prolifMode: prolifOn ? sel.mode : null, buildingId: bId,
    };
  }

  const product = r.products.find(p => p.item === itemId) || r.products[0];
  const bId = chosenBuilding(itemId, chosen);
  const b = buildingInfo(bId);
  const speed = b.speed;
  const sel = getProlifSel(itemId);
  const prolifOn = !!(sel && r.prolif);
  const tier = prolifOn ? D.prolif[sel.tier] : null;
  const selMode = prolifOn ? sel.mode : null;
  let outMult = 1, inMult = 1;
  if (prolifOn) {
    if (selMode === 'speed') { outMult = 1 + tier.speed; inMult = 1 + tier.speed; }
    else { outMult = 1 + tier.extra; inMult = 1; }
  }
  const perMin = (product.amount * 60 / r.time) * speed * outMult;
  const machineCount = rateNeeded / perMin;
  const powerMult = prolifOn ? (1 + tier.power) : 1;
  const powerPerMachine = b.power * powerMult;
  const totalPower = powerPerMachine * machineCount;
  const byproducts = r.products.filter(p => p.item !== product.item).map(p => {
    const bpPerMin = (p.amount * 60 / r.time) * speed * outMult;
    return { item: p.item, rate: bpPerMin * machineCount };
  });
  const children = r.ingredients.map(ing => {
    const ingPerMin = (ing.amount * 60 / r.time) * speed * inMult;
    return calcTree(ing.item, ingPerMin * machineCount, depth + 1, nextVisited);
  });
  return {
    id: nodeId, itemId, rateNeeded, recipeId: chosen, isRaw: false,
    machineCount, perMin, speed, outMult, inMult, prolifOn,
    prolifTier: prolifOn ? sel.tier : null, prolifMode: selMode,
    powerPerMachine, totalPower, byproducts, children, depth, buildingId: bId,
  };
}

// ---- Layout ----
function estimateNodeH(n) {
  let h = 218; // 基础卡片高度（头部 + 设备行 + 徽章 + 配方行 + 原料行）
  if (n.isFractionator) h += 46;
  if (n.byproducts && n.byproducts.length) h += 68;
  return h;
}
function layoutTree(root) {
  const all = [];
  const walk = (n) => { all.push(n); n.children.forEach(walk); };
  walk(root);
  const maxDepth = Math.max(...all.map(n => n.depth));
  for (const n of all) n.col = maxDepth - n.depth;
  const colW = 430, rowH = 300, cardW = 250, cardH = 200;
  let yCursor = 0;
  const yByCol = {};
  function place(n) {
    if (!n.children.length) { n.y = yCursor; yCursor += Math.max(rowH, estimateNodeH(n) + 42); }
    else {
      n.children.forEach(place);
      const ys = n.children.map(c => c.y);
      n.y = (Math.min(...ys) + Math.max(...ys)) / 2;
    }
    const list = (yByCol[n.col] = yByCol[n.col] || []);
    while (true) {
      let push = 0;
      for (const p of list) {
        // 垂直堆叠时按较高一方的高度留出间距，避免高节点（如带副产物）压住下方节点
        const need = Math.max(rowH * 0.85, Math.max(estimateNodeH(n), estimateNodeH(p.n)) + 36);
        const dist = Math.abs(p.y - n.y);
        if (dist < need) push = Math.max(push, need - dist);
      }
      if (!push) break;
      n.y += push + 8;
    }
    list.push({ y: n.y, n });
    n.x = n.col * colW;
  }
  place(root);
  const minY = Math.min(...all.map(n => n.y));
  for (const n of all) n.y -= minY;
  const maxX = Math.max(...all.map(n => n.x)) + cardW;
  const maxY = Math.max(...all.map(n => n.y)) + Math.max(...all.map(n => estimateNodeH(n)));
  return { all, maxX, maxY, colW, rowH, cardW, cardH };
}

// ---- Tree rendering ----
function renderTree(preserveView) {
  const nodesEl = $('nodes'), edgesEl = $('edges'), canvasEl = $('canvas');
  nodesEl.innerHTML = ''; edgesEl.innerHTML = '';
  nodesEl.classList.toggle('animate', !preserveView);
  edgesEl.classList.toggle('animate', !preserveView);
  if (!state.tree) { showEmpty('选择目标产物并计算，产线图会显示在这里。'); return; }
  if (state.tree.isRaw) { showEmpty('该产物当前视为原料终点（直接获取）。<br/>若存在生产配方，可在下方「配方 / 设备 / 增产剂 选择」面板中点击配方卡片展开生产链。'); return; }

  $('emptyState').classList.add('hidden');
  const lay = layoutTree(state.tree);
  const pad = 40;
  const contentW = lay.maxX + pad * 2, contentH = lay.maxY + pad * 2;
  canvasEl.style.width = contentW + 'px'; canvasEl.style.height = contentH + 'px';
  state._contentW = contentW; state._contentH = contentH;
  edgesEl.setAttribute('viewBox', `0 0 ${contentW} ${contentH}`);
  edgesEl.setAttribute('preserveAspectRatio', 'none');
  edgesEl.innerHTML = `
    <defs>
      <linearGradient id="edgeGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%" stop-color="#5fd3a0"/><stop offset="100%" stop-color="#35c6ff"/>
      </linearGradient>
      <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse">
        <path d="M0,0 L10,5 L0,10 z" fill="#35c6ff"/>
      </marker>
    </defs>`;
  for (const n of lay.all) renderNode(n, nodesEl);
  for (const n of lay.all) {
    for (const c of n.children) {
      const childEl = nodesEl.querySelector(`[data-id="${c.id}"]`);
      const parentEl = nodesEl.querySelector(`[data-id="${n.id}"]`);
      const cw = childEl ? childEl.offsetWidth : lay.cardW;
      const ch = childEl ? childEl.offsetHeight : lay.cardH;
      const ph = parentEl ? parentEl.offsetHeight : lay.cardH;
      const x1 = c.x + cw + pad, y1 = c.y + ch / 2 + pad;
      const x2 = n.x + pad, y2 = n.y + ph / 2 + pad;
      const midX = (x1 + x2) / 2;
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('class', 'edge');
      path.setAttribute('d', `M ${x1} ${y1} C ${midX} ${y1}, ${midX} ${y2}, ${x2} ${y2}`);
      path.setAttribute('marker-end', 'url(#arrow)');
      path.setAttribute('pathLength', '1'); // 供描线动画使用
      if (!preserveView) path.style.animationDelay = Math.min(140 + c.depth * 60, 480) + 'ms';
      path.dataset.from = c.id; path.dataset.to = n.id;
      edgesEl.appendChild(path);
    }
  }
  applyZoom();
  if (!preserveView) requestAnimationFrame(() => fitToView());
}
function showEmpty(msg) {
  const es = $('emptyState');
  es.classList.remove('hidden');
  es.innerHTML = `<div class="hero">◉</div><p>${msg}</p>`;
}
function fitToView() {
  const scroll = $('canvasScroll');
  if (!state._contentW || !state._contentH) return;
  scroll.scrollLeft = 0; scroll.scrollTop = 0; // 清除浏览器恢复的原生滚动，避免整体偏移
  const f = 0.85;
  const vw = Math.max(40, (scroll.clientWidth - 40) * f), vh = Math.max(40, (scroll.clientHeight - 40) * f);
  state.zoom = Math.max(ZOOM_MIN, Math.min(Math.min(vw / state._contentW, vh / state._contentH), 1.5));
  state.panX = Math.max(0, (scroll.clientWidth - state._contentW * state.zoom) / 2);
  state.panY = Math.max(0, (scroll.clientHeight - state._contentH * state.zoom) / 2);
  applyZoom();
}
// 把浏览器恢复/残留的原生滚动偏移折叠进 pan（视觉不变），使坐标始终纯净
function foldNativeScroll() {
  const el = $('canvasScroll');
  if (el.scrollLeft) { state.panX -= el.scrollLeft; el.scrollLeft = 0; }
  if (el.scrollTop) { state.panY -= el.scrollTop; el.scrollTop = 0; }
}
function applyZoom() {
  const scrollEl = $('canvasScroll');
  if (scrollEl.scrollLeft) { state.panX -= scrollEl.scrollLeft; scrollEl.scrollLeft = 0; }
  if (scrollEl.scrollTop) { state.panY -= scrollEl.scrollTop; scrollEl.scrollTop = 0; }
  $('canvas').style.transform = `translate(${state.panX}px, ${state.panY}px) scale(${state.zoom})`;
  $('zoomReset').textContent = Math.round(state.zoom * 100) + '%';
}
// 以 (mx,my)（相对画布容器）为中心缩放：保持该点内容在屏幕上不动
function zoomAt(mx, my, ratio) {
  const old = state.zoom;
  const nz = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, old * ratio));
  if (nz === old) return;
  const cx = (mx - state.panX) / old, cy = (my - state.panY) / old;
  state.zoom = nz; state.panX = mx - cx * nz; state.panY = my - cy * nz;
  applyZoom();
}

function renderNode(n, container) {
  const el = document.createElement('div');
  el.className = 'node' + (n.isRaw ? ' raw' : '');
  el.style.left = n.x + 'px'; el.style.top = n.y + 'px';
  el.style.animationDelay = Math.min(n.depth * 55, 330) + 'ms';
  el.dataset.id = n.id;
  const it = D.items[n.itemId] || { zh: n.itemId, img: '' };
  const rateStr = fmt(n.rateNeeded) + ' / min' + (isFluid(n.itemId) ? '（m³）' : '');

  let bodyHTML = '';
  if (n.isRaw) {
    const src = sourceIcon(n.itemId);
    bodyHTML = `
      <div class="machine-line">
        <img src="${src}" alt="" data-imgid="${n.itemId}" onerror="this.style.visibility='hidden'"/>
        <div class="info"><div class="name">${rawSourceName(n.itemId)}</div>
          <div class="sub">${isAlwaysRaw(n.itemId) ? '直接开采/抽取/获取' : '视为原料终点'}</div></div>
        <div class="count">${fmt(n.rateNeeded)} /min</div>
      </div>`;
  } else if (n.isFractionator) {
    const b = buildingInfo(n.buildingId);
    bodyHTML = `
      <div class="machine-line">
        <img src="${b.img || ''}" alt="" data-imgid="${n.buildingId}" onerror="this.style.visibility='hidden'"/>
        <div class="info"><div class="name">${b.zh}</div>
          <div class="sub">${fmt(n.powerPerMachine)} MW · 转化率 ${(n.conversion*100).toFixed(1)}%</div></div>
        <div class="count">×${fmt(n.machineCount)}</div>
      </div>
      <div class="node-badges">${prolifSelHTML(n.itemId, n.prolifOn, n.prolifTier, n.prolifMode)}</div>
      <div class="node-recipe">配方 · 分馏制重氢 <span class="change" data-changeitem="${n.itemId}">切换 ⇋</span></div>
      <div class="node-ings">
        <div class="ing-chip" data-info="氢" title="查看物品详情"><img src="${itemImg('氢')}" alt="" data-imgid="氢" onerror="this.style.visibility='hidden'"/>
          <span>${itemZh('氢')}</span><span class="amt">${fmt(n.rateNeeded)}</span></div>
      </div>
      <div class="node-frac-note">氢循环使用 · 流速 ${FRAC_FLOW}/min · 净消耗=产量</div>`;
  } else {
    const r = D.recipes[n.recipeId];
    const b = buildingInfo(n.buildingId);
    const effPerMin = n.perMin;
    const powerStr = n.powerPerMachine > 0 ? fmt(n.powerPerMachine) + ' MW' : '可变功率';
    const speedBadge = n.speed !== 1 ? `<span class="oc-badge">${fmt(n.speed)}x</span>` : '';
    bodyHTML = `
      <div class="machine-line">
        <img src="${b.img || ''}" alt="" data-imgid="${n.buildingId}" onerror="this.style.visibility='hidden'"/>
        <div class="info"><div class="name">${b.zh}</div>
          <div class="sub">${fmt(effPerMin)} /min · ${powerStr}</div></div>
        <div class="count">×${fmt(n.machineCount)}</div>
      </div>
      <div class="node-badges">${speedBadge}${prolifSelHTML(n.itemId, n.prolifOn, n.prolifTier, n.prolifMode)}</div>
      ${bldRowHTML(n)}
      <div class="node-recipe">配方 · ${escapeHtml(r.zh)} <span class="change" data-changeitem="${n.itemId}">切换 ⇋</span></div>
      <div class="node-ings">
        ${r.ingredients.map(ing => {
          const perMin = (ing.amount * 60 / r.time) * n.speed * n.inMult * n.machineCount;
          return `<div class="ing-chip" data-info="${ing.item}" title="查看物品详情"><img src="${itemImg(ing.item)}" alt="" data-imgid="${ing.item}" onerror="this.style.visibility='hidden'"/>
            <span>${itemZh(ing.item)}</span><span class="amt">${fmt(perMin)}</span></div>`;
        }).join('')}
      </div>
      ${n.byproducts && n.byproducts.length ? `
      <div class="node-byproducts"><div class="bp-label">副产物</div><div class="bp-chips">
        ${n.byproducts.map(bp => `<div class="byproduct-chip" data-info="${bp.item}" title="查看物品详情"><img src="${itemImg(bp.item)}" alt="" data-imgid="${bp.item}" onerror="this.style.visibility='hidden'"/>
          <span>${itemZh(bp.item)}</span><span class="amt">${fmt(bp.rate)}</span></div>`).join('')}
      </div></div>` : ''}`;
  }
  el.innerHTML = `
    <div class="node-head" data-info="${n.itemId}" title="查看物品详情">
      <img class="p-img" src="${it.img || ''}" alt="" data-imgid="${n.itemId}" onerror="this.style.visibility='hidden'"/>
      <div class="p-info"><div class="p-zh">${it.zh}</div><div class="p-rate">${rateStr}</div></div>
    </div>
    <div class="node-body">${bodyHTML}</div>`;
  el.addEventListener('mouseenter', () => {
    document.querySelectorAll('.edge').forEach(p => { if (p.dataset.from === n.id || p.dataset.to === n.id) p.classList.add('hi'); });
  });
  el.addEventListener('mouseleave', () => { document.querySelectorAll('.edge').forEach(p => p.classList.remove('hi')); });
  container.appendChild(el);
  el.querySelectorAll('.change[data-changeitem]').forEach(sp => {
    sp.addEventListener('click', () => {
      setPickerExpanded(true); // 面板折叠时先展开
      setTimeout(() => {
        const g = document.querySelector(`.picker-group[data-item="${sp.dataset.changeitem}"]`);
        if (g) { g.scrollIntoView({ behavior: 'smooth', block: 'center' }); g.style.outline = '2px solid var(--accent)'; setTimeout(() => g.style.outline = '', 1500); }
      }, 80);
    });
  });
}

function rawSourceName(itemId) {
  const map = {
    '采矿机': '采矿机', '抽水站': '抽水站', '原油萃取站': '原油萃取站',
    '轨道采集器': '轨道采集器', '射线接收站': '射线接收站',
  };
  const bId = D.rawSource[itemId];
  if (bId && map[bId]) return map[bId];
  return '基础资源';
}
function sourceIcon(itemId) {
  const bId = D.rawSource[itemId];
  if (bId && D.buildings[bId]) return D.buildings[bId].img || itemImg(itemId);
  return itemImg(itemId);
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }

function placeholderSrc(id) {
  const it = D.items[id];
  const label = (it && it.zh) ? it.zh : String(id || '?');
  const ch = Array.from(label)[0] || '?';
  const colors = ['#35c6ff', '#2ad19e', '#9a7bff', '#ffb24d', '#ff6b6b', '#5fe3ff'];
  let h = 7; for (let i = 0; i < (id || '').length; i++) h = (h * 31 + (id || '').charCodeAt(i)) >>> 0;
  const c = colors[h % colors.length];
  const cv = document.createElement('canvas'); cv.width = 64; cv.height = 64;
  const ctx = cv.getContext('2d');
  ctx.fillStyle = 'rgba(255,255,255,0.06)'; ctx.fillRect(0, 0, 64, 64);
  ctx.fillStyle = c; ctx.beginPath(); ctx.arc(32, 32, 24, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#070d1a'; ctx.font = 'bold 26px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(ch, 32, 33);
  return cv.toDataURL('image/png');
}

// ---- Table view（仿 dsp-calc.pro 统计表：每行一个物品，可切配方/设备/增产剂） ----
function computeAggregates() {
  const rawTot = {}, machineTot = {}, byproductTot = {};
  let totalPower = 0, prolifCnt = 0;
  (function walk(n) {
    if (n.isRaw) { rawTot[n.itemId] = (rawTot[n.itemId] || 0) + n.rateNeeded; }
    else {
      machineTot[n.buildingId] = (machineTot[n.buildingId] || 0) + n.machineCount;
      totalPower += n.totalPower || 0;
      if (n.prolifOn) prolifCnt++;
      if (n.byproducts) for (const bp of n.byproducts) byproductTot[bp.item] = (byproductTot[bp.item] || 0) + bp.rate;
      n.children.forEach(walk);
    }
  })(state.tree);
  return { rawTot, machineTot, byproductTot, totalPower, prolifCnt };
}
function renderTableView() {
  const container = $('tableContainer');
  container.innerHTML = '';
  if (!state.tree) { container.innerHTML = '<p class="table-empty">请选择产物并计算。</p>'; return; }
  if (state.tree.isRaw) { container.innerHTML = '<p class="table-empty">该产物当前视为原料终点（直接获取）。<br/>若存在生产配方，可在左下「配方 / 设备 / 增产剂 选择」面板中点击配方卡片展开生产链。</p>'; return; }

  const agg = computeAggregates();
  const it0 = D.items[state.itemId];
  const machineStr = Object.entries(agg.machineTot).map(([b, c]) => `<span class="t2-stat-chip"><img src="${buildingInfo(b).img || ''}" alt="" data-imgid="${b}" onerror="this.style.visibility='hidden'"/>${buildingInfo(b).zh}×${fmt(c)}</span>`).join('');
  const rawStr = Object.entries(agg.rawTot).map(([id, r]) => `<span class="t2-stat-chip"><img src="${itemImg(id)}" alt="" data-imgid="${id}" onerror="this.style.visibility='hidden'"/>${itemZh(id)} ${fmt(r)}/min</span>`).join('');
  const bpStr = Object.entries(agg.byproductTot).map(([id, r]) => `<span class="t2-stat-chip"><img src="${itemImg(id)}" alt="" data-imgid="${id}" onerror="this.style.visibility='hidden'"/>${itemZh(id)} ${fmt(r)}/min</span>`).join('');
  const stats = document.createElement('div'); stats.className = 't2-stats';
  stats.innerHTML = `
    <div class="t2-stat final"><span class="k">目标产物</span><span class="v"><img src="${it0.img || ''}" alt="" data-imgid="${state.itemId}" onerror="this.style.visibility='hidden'"/>${it0.zh} ${fmt(state.rate)}/min</span></div>
    <div class="t2-stat"><span class="k">建筑统计</span><span class="v">${machineStr || '-'}</span></div>
    <div class="t2-stat"><span class="k">原矿输入</span><span class="v">${rawStr || '-'}</span></div>
    ${agg.totalPower > 0 ? `<div class="t2-stat"><span class="k">预估电力</span><span class="v">${fmt(agg.totalPower)} MW</span></div>` : ''}
    ${bpStr ? `<div class="t2-stat alt"><span class="k">副产物</span><span class="v">${bpStr}</span></div>` : ''}`;

  // 行 = 树中物品去重（首次出现 = 最浅层），目标产物排最前
  const seen = new Map();
  (function walk(n) { if (!seen.has(n.itemId)) seen.set(n.itemId, n); n.children.forEach(walk); })(state.tree);
  const rows = [...seen.values()].sort((a, b) => (a.itemId === state.itemId ? -1 : b.itemId === state.itemId ? 1 : a.depth - b.depth));

  const table = document.createElement('table'); table.className = 't2-table';
  table.innerHTML = `<thead><tr><th class="t2-op">操作</th><th>物品 / 产能</th><th>工厂 / 工厂类型</th><th class="t2-recipes">配方选取（点击切换）</th><th>增产剂</th></tr></thead>`;
  const tbody = document.createElement('tbody');
  for (const n of rows) tbody.appendChild(buildTableRow(n));
  table.appendChild(tbody);
  container.appendChild(stats);
  container.appendChild(table);
}
function buildTableRow(n) {
  const tr = document.createElement('tr');
  const it = D.items[n.itemId] || { zh: n.itemId, img: '' };
  const isFinal = n.itemId === state.itemId;
  // 操作列
  let opHTML = '';
  if (D.rawResources.includes(n.itemId) && !isAlwaysRaw(n.itemId) && recipesForItem(n.itemId).length) {
    const asRaw = (state.recipeChoice[n.itemId] || defaultRecipe(n.itemId)) === '__raw__';
    opHTML = `<button type="button" class="t2-raw-toggle${asRaw ? ' active' : ''}" data-item="${n.itemId}" title="在「视为原料终点」与「展开生产链」之间切换">${asRaw ? '已视为原矿' : '展开生产'}</button>`;
  } else if (isFinal) {
    opHTML = '<span class="t2-final-badge">目标</span>';
  }
  // 产能
  const bypHTML = (n.byproducts && n.byproducts.length) ? `<div class="t2-byp">副产：${n.byproducts.map(bp => `${itemZh(bp.item)} +${fmt(bp.rate)}/min`).join('、')}</div>` : '';
  const rateHTML = `<div class="t2-rate">${fmt(n.rateNeeded)}/min${isFluid(n.itemId) ? '（m³）' : ''}</div>`;
  // 工厂
  let facHTML = '';
  if (n.isRaw) {
    const b = D.buildings[D.rawSource[n.itemId]];
    facHTML = `<div class="t2-fac"><img src="${b ? b.img : ''}" alt="" title="${rawSourceName(n.itemId)}" onerror="this.style.visibility='hidden'"/><span class="t2-fac-src">${rawSourceName(n.itemId)}</span></div>`;
  } else {
    const b = buildingInfo(n.buildingId);
    facHTML = `<div class="t2-fac"><img src="${b.img || ''}" alt="" title="${b.zh}" onerror="this.style.visibility='hidden'"/><b>×${fmt(n.machineCount)}</b><span class="t2-fac-name">${b.zh}</span></div>`;
    const r = D.recipes[n.recipeId];
    if (r && !r.isFractionator && r.machine !== '能量枢纽') {
      const cats = D.categoryOrder[r.machine] || [];
      if (cats.length > 1) {
        facHTML += `<div class="t2-blds">` + cats.map(bId => {
          const bi = buildingInfo(bId);
          return `<button type="button" class="t2-bld-btn${bId === n.buildingId ? ' active' : ''}" data-item="${n.itemId}" data-bld="${bId}" title="${bi.zh} ${fmt(bi.speed)}x · ${bi.power}MW"><img src="${bi.img || ''}" alt="${bi.zh}" onerror="this.style.visibility='hidden'"/></button>`;
        }).join('') + `</div>`;
      }
    }
  }
  // 配方选取
  const recHTML = n.isRaw
    ? `<div class="t2-no-recipe">直接获取</div>`
    : recipesForItem(n.itemId).map(r => recipeCardHTML(n.itemId, r, n.recipeId === r.id)).join('');
  // 增产剂
  const prolifHTML = n.isRaw ? '<span class="t2-none">—</span>' : prolifSelHTML(n.itemId, n.prolifOn, n.prolifTier, n.prolifMode);
  tr.innerHTML = `
    <td class="t2-op">${opHTML}</td>
    <td><div class="t2-item"><img src="${it.img || ''}" alt="" data-info="${n.itemId}" title="查看物品详情" onerror="this.style.visibility='hidden'"/><div><div class="t2-name${isFinal ? ' final' : ''}" data-info="${n.itemId}">${it.zh}</div>${rateHTML}${bypHTML}</div></div></td>
    <td>${facHTML}</td>
    <td class="t2-recipes"><div class="t2-recipe-list">${recHTML}</div></td>
    <td class="t2-prolif">${prolifHTML}</td>`;
  return tr;
}
// ---- Recipe picker（dsp-calc 风格配方卡片，抽屉面板） ----
function recipeCardHTML(itemId, r, active) {
  // 显示具体设备名（按当前设备等级与用户选择），而非设备类别
  const bId = active ? (chosenBuilding(itemId, r.id) || defaultBuildingFor(r.machine)) : defaultBuildingFor(r.machine);
  const bName = buildingInfo(bId).zh;
  const ins = r.ingredients.map(i => `<span class="rc-chip"><img src="${itemImg(i.item)}" alt="" title="${itemZh(i.item)}" onerror="this.style.visibility='hidden'"/><b>×${fmt(i.amount)}</b></span>`).join('');
  const outs = r.products.map(p => `<span class="rc-chip out${p.item === itemId ? ' main' : ''}"><img src="${itemImg(p.item)}" alt="" title="${itemZh(p.item)}" onerror="this.style.visibility='hidden'"/><b>×${fmt(p.amount)}</b></span>`).join('');
  return `<div class="recipe-card${active ? ' active' : ''}" data-item="${itemId}" data-recipe="${r.id}" role="button" title="点击选用此配方">
    <div class="rc-flow">${ins}<span class="rc-arrow">→</span>${outs}</div>
    <div class="rc-meta">${escapeHtml(bName)} · ${escapeHtml(r.rawTime || r.time + 's')}${r.prolif ? '<span class="rc-badge">可增产</span>' : ''}${r.hand ? '<span class="rc-badge hand">可手搓</span>' : ''}${r.isFractionator ? '<span class="rc-badge">分馏</span>' : ''}</div>
  </div>`;
}
function setPickerExpanded(exp) {
  state.pickerOpen = exp;
  $('pickerDrawer').classList.toggle('open', exp);
  $('pickerToggle').classList.toggle('active', exp);
}
function updatePickerLabel(count) {
  $('pickerCount').textContent = count ? `共 ${count} 项` : '';
  $('pickerBadge').textContent = count ? String(count) : '';
}
function renderRecipePicker() {
  const holder = $('recipePicker');
  const prevScroll = holder.scrollTop;
  holder.innerHTML = '';
  if (!state.tree) { updatePickerLabel(0); return; }
  const seen = new Set(); const rows = [];
  (function walk(n) { if (!seen.has(n.itemId)) { seen.add(n.itemId); rows.push(n); } n.children.forEach(walk); })(state.tree);
  let groupCount = 0;
  for (const n of rows) {
    const itemId = n.itemId;
    const list = recipesForItem(itemId);
    if (!list.length && !D.rawResources.includes(itemId)) continue;
    groupCount++;
    const currentChoice = state.recipeChoice[itemId] || defaultRecipe(itemId);
    const group = document.createElement('div');
    group.className = 'picker-group'; group.dataset.item = itemId;
    const it = D.items[itemId] || {};
    group.innerHTML = `<div class="head" data-info="${itemId}" title="查看物品详情"><img src="${it.img || ''}" alt="" onerror="this.style.visibility='hidden'"/><span class="zh">${it.zh || itemId}</span><span class="rate">${fmt(n.rateNeeded)}/min</span></div><div class="opts"></div>`;
    const opts = group.querySelector('.opts');
    if (D.rawResources.includes(itemId)) {
      opts.insertAdjacentHTML('beforeend', `<div class="recipe-card raw${currentChoice === '__raw__' ? ' active' : ''}" data-item="${itemId}" data-recipe="__raw__" role="button" title="点击后该物品视为原料终点，不再展开生产链"><div class="rc-meta">直接获取 / 视为原料终点</div></div>`);
    }
    for (const r of list) {
      opts.insertAdjacentHTML('beforeend', recipeCardHTML(itemId, r, currentChoice === r.id));
    }
    // building options + prolif toggle
    if (currentChoice !== '__raw__') {
      const r = D.recipes[currentChoice];
      if (r && !r.isFractionator && r.machine !== '能量枢纽') {
        const cats = D.categoryOrder[r.machine] || [];
        if (cats.length > 1) {
          const ctrl = document.createElement('div'); ctrl.className = 'picker-controls';
          let html = '<div class="pc-bld"><span class="pc-bld-lbl">设备</span><div class="pc-bld-btns">';
          const curBld = chosenBuilding(itemId, currentChoice);
          for (const bId of cats) {
            const b = buildingInfo(bId);
            html += `<button class="pc-bld-btn${bId === curBld ? ' active' : ''}" data-bld="${bId}" data-item="${itemId}">${b.zh} ${fmt(b.speed)}x</button>`;
          }
          html += '</div></div>';
          ctrl.innerHTML = html;
          group.appendChild(ctrl);
        }
      }
      if (r && (r.prolif || r.isFractionator)) {
        const sel = getProlifSel(itemId);
        const ctrl = document.createElement('div'); ctrl.className = 'picker-controls';
        ctrl.innerHTML = `<div class="pc-prolif"><span class="pc-bld-lbl">增产剂</span>${prolifSelHTML(itemId, !!sel, sel ? sel.tier : null, sel ? sel.mode : null)}</div>`;
        group.appendChild(ctrl);
      }
    }
    holder.appendChild(group);
  }
  holder.scrollTop = prevScroll;
  updatePickerLabel(groupCount);
  // wire building buttons
  holder.querySelectorAll('.pc-bld-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.buildingChoice[btn.dataset.item] = btn.dataset.bld;
      recomputeAndRender(true);
    });
  });
}
function setAllProlif(use) {
  if (!state.hasComputed || !state.tree || state.tree.isRaw) return;
  if (use) {
    if (state.prolifTier === 'none') { state.prolifTier = 'Mk.I'; $('prolifTier').value = 'Mk.I'; }
    const seen = new Set();
    (function walk(n) {
      if (seen.has(n.itemId)) return; seen.add(n.itemId);
      if (!n.isRaw) {
        const r = D.recipes[n.recipeId];
        if (r && (r.prolif || r.isFractionator)) state.prolifSel[n.itemId] = { tier: state.prolifTier, mode: state.prolifMode };
      }
      n.children.forEach(walk);
    })(state.tree);
  } else {
    state.prolifSel = {};
  }
  recomputeAndRender(true);
}

// ---- Main ----
function recomputeAndRender(preserveView) {
  if (!state.hasComputed || !state.itemId || !state.rate) return;
  nodeCounter = 0;
  state.tree = calcTree(state.itemId, state.rate);
  if (state.viewMode === 'table') renderTableView(); else renderTree(preserveView);
  renderRecipePicker();
  renderSummary();
  // 目标产物默认视为原料终点时，自动展开配方面板方便选择生产配方
  if (state.tree && state.tree.isRaw && recipesForItem(state.itemId).length) setPickerExpanded(true);
}
function renderSummary() {
  if (!state.tree) { $('summary').textContent = '请选择产物并点击「计算产线」'; return; }
  if (state.tree.isRaw) { $('summary').textContent = '该产物视为原料终点，可在下方配方面板选择生产配方'; return; }
  const rawTot = {}, machineTot = {}, byproductTot = {};
  let totalPower = 0, prolifCnt = 0;
  (function walk(n) {
    if (n.isRaw) { rawTot[n.itemId] = (rawTot[n.itemId] || 0) + n.rateNeeded; }
    else {
      machineTot[n.buildingId] = (machineTot[n.buildingId] || 0) + n.machineCount;
      totalPower += n.totalPower || 0;
      if (n.prolifOn) prolifCnt++;
      if (n.byproducts) for (const bp of n.byproducts) byproductTot[bp.item] = (byproductTot[bp.item] || 0) + bp.rate;
      n.children.forEach(walk);
    }
  })(state.tree);
  const it = D.items[state.itemId];
  const machineStr = Object.entries(machineTot).map(([b, c]) => `${buildingInfo(b).zh}×${fmt(c)}`).join('，');
  const rawStr = Object.entries(rawTot).map(([id, r]) => `${itemZh(id)} ${fmt(r)}/min`).join('，');
  const bpStr = Object.entries(byproductTot).map(([id, r]) => `${itemZh(id)} ${fmt(r)}/min`).join('，');
  const parts = [`<strong>${it.zh}</strong> ${fmt(state.rate)}/min`, `设备：${machineStr || '-'}`, `原料：${rawStr || '-'}`];
  if (totalPower > 0) parts.push(`功率：${fmt(totalPower)} MW`);
  if (prolifCnt > 0) parts.push(`增产剂：${prolifCnt} 处`);
  if (bpStr) parts.push(`副产物：${bpStr}`);
  $('summary').innerHTML = parts.join(' | ');
}

// ---- View switching ----
function switchView(mode) {
  state.viewMode = mode;
  const isTree = mode === 'tree';
  $('canvasScroll').style.display = isTree ? '' : 'none';
  $('tableContainer').style.display = isTree ? 'none' : '';
  ['zoomOut','zoomReset','zoomIn'].forEach(id => $(id).style.display = isTree ? '' : 'none');
  document.querySelectorAll('.view-btn').forEach(b => b.classList.toggle('active', b.dataset.view === mode));
  if (isTree) renderTree(false); else renderTableView();
}

// ---- Export PNG ----
// 等待克隆节点中的图片全部加载完成；仅加载失败的图片才退回首字占位图
function waitImagesLoaded(elm) {
  const imgs = [...elm.querySelectorAll('img')];
  return Promise.all(imgs.map(img => {
    if (img.complete && img.naturalWidth > 0) return Promise.resolve();
    return new Promise(res => {
      img.addEventListener('load', res, { once: true });
      img.addEventListener('error', res, { once: true });
      setTimeout(res, 5000); // 兜底超时，避免个别图片阻塞导出
    });
  })).then(() => {
    imgs.forEach(img => {
      const id = img.dataset.imgid;
      if (id && (!img.complete || img.naturalWidth === 0)) img.src = placeholderSrc(id);
    });
  });
}
function toPngBlob(canvas) {
  return new Promise((resolve, reject) => {
    try { canvas.toBlob(b => b ? resolve(b) : reject(new Error('empty-blob')), 'image/png'); }
    catch (err) { reject(err); } // SecurityError：画布被图片污染（file:// 场景）
  });
}
async function renderHtml2Canvas(elm, w, h, label) {
  if (!window.html2canvas) { alert('导出组件未加载，请刷新页面后重试。'); return; }
  elm.style.position = 'fixed'; elm.style.left = '-20000px'; elm.style.top = '0'; elm.style.zIndex = '-1';
  elm.style.width = w + 'px'; elm.style.height = h + 'px'; elm.style.margin = '0'; elm.style.background = '#08101f';
  document.body.appendChild(elm);
  try {
    const opts = { backgroundColor: '#08101f', useCORS: true, allowTaint: false, logging: false,
      scale: Math.min(2, Math.max(1, 6000 / Math.max(w, h))) };
    await waitImagesLoaded(elm);
    let canvas = await html2canvas(elm, opts);
    let blob;
    try { blob = await toPngBlob(canvas); }
    catch (err) {
      // 以 file:// 打开页面时同源图片会污染画布：退回首字占位图重渲染，保证导出可用
      elm.querySelectorAll('img').forEach(img => { const id = img.dataset.imgid; if (id) img.src = placeholderSrc(id); });
      await new Promise(r => setTimeout(r, 80));
      canvas = await html2canvas(elm, opts);
      blob = await toPngBlob(canvas);
    }
    const a = document.createElement('a'); const it = D.items[state.itemId];
    a.download = `${it?.zh || 'production'}-${state.rate}pmin-${label}.png`;
    a.href = URL.createObjectURL(blob); a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  } finally { elm.remove(); }
}
async function exportPng() {
  if (!state.tree) { alert('请先计算产线'); return; }
  if (state.viewMode === 'table') {
    const wrap = $('tableContainer');
    if (!wrap.querySelector('.t2-table')) return;
    const clone = wrap.cloneNode(true); clone.style.width = wrap.scrollWidth + 'px';
    clone.querySelectorAll('.prolif-sel:not(.on)').forEach(el => el.remove());
    await renderHtml2Canvas(clone, wrap.scrollWidth, wrap.scrollHeight, 'table'); return;
  }
  const canvasEl = $('canvas'); const w = canvasEl.offsetWidth, h = canvasEl.offsetHeight;
  const clone = canvasEl.cloneNode(true); clone.style.transform = 'none'; clone.style.position = 'relative';
  clone.style.left = '0'; clone.style.top = '0';
  clone.querySelectorAll('.prolif-sel:not(.on)').forEach(el => el.remove());
  // 固定入场动画的最终状态，避免导出瞬间节点/连线处于透明起始帧
  clone.querySelectorAll('.nodes, .edges').forEach(el => el.classList.remove('animate'));
  clone.querySelectorAll('.node, .edge').forEach(el => { el.style.animation = 'none'; el.style.opacity = ''; });
  await renderHtml2Canvas(clone, w, h, 'tree');
}

// ---- Item details modal ----
const usageIndex = {};
for (const r of Object.values(D.recipes)) {
  for (const ing of r.ingredients) (usageIndex[ing.item] = usageIndex[ing.item] || []).push(r.id);
}
const RAW_SOURCE_DESC = {
  '采矿机': '分布于行星表面的矿脉，使用采矿机开采',
  '抽水站': '海洋 / 湖泊，使用抽水站抽取',
  '原油萃取站': '油井，使用原油萃取站萃取',
  '轨道采集器': '气态 / 冰巨星轨道，使用轨道采集器采集',
  '射线接收站': '戴森球能量，使用射线接收站接收临界光子',
};
function recipeMachineIcon(r) {
  const ids = D.categoryOrder[r.machine] || [r.machine];
  return buildingInfo(ids[0]).img || '';
}
function infoChipHTML(itemId, amount, hl) {
  return `<span class="info-chip${hl ? ' hl' : ''}" data-info="${itemId}" title="查看物品详情">
    <img src="${itemImg(itemId)}" alt="" onerror="this.style.visibility='hidden'"/>
    <span>${itemZh(itemId)}</span>${amount != null ? `<b>×${fmt(amount)}</b>` : ''}</span>`;
}
function recipeRowHTML(r, highlightItem) {
  const ins = r.ingredients.map(i => infoChipHTML(i.item, i.amount, i.item === highlightItem)).join('');
  const outs = r.products.map(p => infoChipHTML(p.item, p.amount, p.item === highlightItem)).join('');
  const badges = (r.prolif ? '<span class="ri-badge">可增产</span>' : '') + (r.hand ? '<span class="ri-badge hand">可手搓</span>' : '');
  const bName = buildingInfo(defaultBuildingFor(r.machine)).zh;
  return `<div class="info-recipe">
    <div class="ir-head">
      <img src="${recipeMachineIcon(r)}" alt="" onerror="this.style.visibility='hidden'"/>
      <span class="ir-name">${escapeHtml(r.zh)}</span>
      <span class="ir-machine">${escapeHtml(bName)}</span>
      <span class="ir-time">${escapeHtml(r.rawTime || r.time + 's')}</span>
      ${badges}
    </div>
    <div class="ir-flow">${ins}<span class="ir-arrow">→</span>${outs}</div>
  </div>`;
}
function openInfo(itemId) {
  const it = D.items[itemId];
  if (!it) return;
  $('itemDropdown').classList.add('hidden');
  const img = $('infoImg');
  img.src = it.img || ''; img.style.visibility = it.img ? 'visible' : 'hidden';
  $('infoName').textContent = it.zh;
  const subBits = [];
  if (it.attrs) subBits.push('属性：' + it.attrs);
  if (it.alias) subBits.push('别称：' + it.alias);
  if (isFluid(itemId)) subBits.push('流体（m³）');
  $('infoSub').textContent = subBits.join(' · ');
  $('infoWiki').href = 'https://wiki.biligame.com/dsp/' + encodeURIComponent(it.zh);

  const srcHTML = [];
  if (D.rawResources.includes(itemId)) {
    const bId = D.rawSource[itemId];
    const b = bId ? D.buildings[bId] : null;
    srcHTML.push(`<div class="info-src">
      <img src="${b ? b.img : ''}" alt="" onerror="this.style.visibility='hidden'"/>
      <div><div class="src-name">${rawSourceName(itemId)} · 自然资源</div>
      <div class="src-desc">${escapeHtml(RAW_SOURCE_DESC[bId] || '直接获取的基础资源')}</div></div></div>`);
  }
  const produces = recipesForItem(itemId);
  const uses = (usageIndex[itemId] || []).map(id => D.recipes[id]).filter(Boolean);
  if (!srcHTML.length) {
    srcHTML.push(`<div class="info-src"><div><div class="src-name">合成产物</div>
      <div class="src-desc">由生产设备制造，见下方「生产流程」</div></div></div>`);
  }
  const prodHTML = produces.length ? produces.map(r => recipeRowHTML(r, itemId)).join('') : '<p class="info-none">无合成配方（直接获取）</p>';
  const useHTML = uses.length ? uses.map(r => recipeRowHTML(r, itemId)).join('') : '<p class="info-none">暂无下游配方使用该物品</p>';
  $('infoBody').innerHTML = `
    <div class="info-sec"><div class="info-sec-title">介绍</div>
      <p class="info-desc">${it.desc ? escapeHtml(it.desc) : '暂无介绍，可点击右上角前往 BWIKI 查看。'}</p></div>
    <div class="info-sec"><div class="info-sec-title">来源</div>${srcHTML.join('')}</div>
    <div class="info-sec"><div class="info-sec-title">生产流程<span class="sec-count">${produces.length} 个配方</span></div>${prodHTML}</div>
    <div class="info-sec"><div class="info-sec-title">用途<span class="sec-count">${uses.length} 个配方</span></div>${useHTML}</div>`;
  $('infoModal').classList.remove('hidden');
}
function closeInfo() { $('infoModal').classList.add('hidden'); }

// ---- Wiring ----
function wire() {
  const scroll = $('canvasScroll');
  const search = $('itemSearch');
  search.addEventListener('focus', () => renderDropdown(search.value));
  search.addEventListener('input', () => renderDropdown(search.value));
  document.addEventListener('click', (e) => { if (!e.target.closest('.combo')) $('itemDropdown').classList.add('hidden'); });
  $('itemDropdown').addEventListener('click', (e) => { if (e.target.closest('[data-info]')) return; const it = e.target.closest('.drop-item'); if (it && it.dataset.id) pickItem(it.dataset.id); });
  $('rateInput').addEventListener('input', (e) => {
    state.rate = parseFloat(e.target.value) || 0;
    document.querySelectorAll('.rate-presets button').forEach(b => b.classList.toggle('active', parseFloat(b.dataset.v) === state.rate));
  });
  document.querySelectorAll('.rate-presets button').forEach(b => b.addEventListener('click', () => {
    state.rate = parseFloat(b.dataset.v); $('rateInput').value = state.rate;
    document.querySelectorAll('.rate-presets button').forEach(x => x.classList.toggle('active', x === b));
  }));
  document.querySelectorAll('.tier-btn').forEach(b => b.addEventListener('click', () => {
    state.defaultTier = b.dataset.tier; state.buildingChoice = {};
    document.querySelectorAll('.tier-btn').forEach(x => x.classList.toggle('active', x === b));
    recomputeAndRender();
  }));
  $('prolifTier').addEventListener('change', (e) => {
    state.prolifTier = e.target.value;
    // 全局等级作为默认/批量值：同步到所有已启用的产物
    if (state.prolifTier !== 'none') {
      for (const k of Object.keys(state.prolifSel)) state.prolifSel[k].tier = state.prolifTier;
    }
    recomputeAndRender(true);
  });
  $('prolifMode').addEventListener('change', (e) => {
    state.prolifMode = e.target.value;
    for (const k of Object.keys(state.prolifSel)) state.prolifSel[k].mode = state.prolifMode;
    recomputeAndRender(true);
  });
  $('treatOreAsRaw').addEventListener('change', (e) => { state.treatOreAsRaw = e.target.checked; state.recipeChoice = {}; recomputeAndRender(); });
  $('sloopAll').addEventListener('click', () => setAllProlif(true));
  $('sloopNone').addEventListener('click', () => setAllProlif(false));
  $('calcBtn').addEventListener('click', () => {
    if (!state.itemId) { alert('请先选择产物'); $('itemSearch').focus(); return; }
    if (!state.rate || state.rate <= 0) { alert('请输入有效的每分钟产量'); return; }
    state.hasComputed = true;
    recomputeAndRender();
  });
  document.querySelectorAll('.view-btn').forEach(btn => btn.addEventListener('click', () => {
    if (!state.hasComputed) return;
    switchView(btn.dataset.view);
  }));
  $('zoomIn').addEventListener('click', () => zoomAt(scroll.clientWidth / 2, scroll.clientHeight / 2, 1.25));
  $('zoomOut').addEventListener('click', () => zoomAt(scroll.clientWidth / 2, scroll.clientHeight / 2, 1 / 1.25));
  $('zoomReset').addEventListener('click', () => fitToView());
  $('exportPng').addEventListener('click', exportPng);

  // 物品详情 / 增产剂选择 / 配方卡片 / 设备切换 / 原矿切换（全局事件委托）
  document.addEventListener('click', (e) => {
    const ps = e.target.closest('.ps-btn');
    if (ps) { if (state.hasComputed) handleProlifSelClick(ps); return; }
    const card = e.target.closest('.recipe-card');
    if (card) {
      const itemId = card.dataset.item, rid = card.dataset.recipe;
      if (!itemId || !rid || !state.hasComputed) return;
      if (rid === '__raw__') {
        if (state.recipeChoice[itemId] !== '__raw__') { state.recipeChoice[itemId] = '__raw__'; recomputeAndRender(true); }
        return;
      }
      if (state.recipeChoice[itemId] !== rid) {
        state.recipeChoice[itemId] = rid;
        delete state.buildingChoice[itemId]; // 新配方可能属于不同设备类别
        recomputeAndRender(true);
      }
      return;
    }
    const bldBtn = e.target.closest('.t2-bld-btn, .node-bld-btn');
    if (bldBtn) { state.buildingChoice[bldBtn.dataset.item] = bldBtn.dataset.bld; recomputeAndRender(true); return; }
    const rawT = e.target.closest('.t2-raw-toggle');
    if (rawT) {
      const itemId = rawT.dataset.item;
      const cur = state.recipeChoice[itemId] || defaultRecipe(itemId);
      if (cur === '__raw__') { const first = recipesForItem(itemId)[0]; if (first) state.recipeChoice[itemId] = first.id; }
      else state.recipeChoice[itemId] = '__raw__';
      recomputeAndRender(true); return;
    }
    const infoEl = e.target.closest('[data-info]');
    if (infoEl && infoEl.dataset.info) openInfo(infoEl.dataset.info);
  });
  $('pickerToggle').addEventListener('click', () => setPickerExpanded(!state.pickerOpen));
  $('drawerClose').addEventListener('click', () => setPickerExpanded(false));
  setPickerExpanded(false);
  $('infoClose').addEventListener('click', closeInfo);
  $('infoMask').addEventListener('click', closeInfo);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeInfo(); setPickerExpanded(false); } });

  // sidebar drag-to-scroll
  const sidebar = document.querySelector('.controls');
  const getScrollEl = () => { const p = $('recipePicker'); return (p && state.pickerOpen && p.scrollHeight > p.clientHeight) ? p : sidebar; };
  let sDrag = null, sWasDrag = false;
  sidebar.addEventListener('mousedown', (e) => {
    if (e.target.closest('input, button, select, textarea')) return;
    const el = getScrollEl(); sDrag = { y: e.clientY, top: el.scrollTop, el, moved: false }; sWasDrag = false;
  });
  document.addEventListener('mousemove', (e) => {
    if (!sDrag) return; const dy = e.clientY - sDrag.y;
    if (!sDrag.moved && Math.abs(dy) > 5) { sDrag.moved = true; sWasDrag = true; sidebar.classList.add('dragging'); }
    if (sDrag.moved) { sDrag.el.scrollTop = sDrag.top - dy; e.preventDefault(); }
  });
  document.addEventListener('mouseup', () => { if (sDrag) { sDrag = null; sidebar.classList.remove('dragging'); } });
  sidebar.addEventListener('click', (e) => { if (sWasDrag) { sWasDrag = false; e.preventDefault(); e.stopPropagation(); } }, true);

  // table drag
  const tc = $('tableContainer'); let tDrag = null;
  tc.addEventListener('mousedown', (e) => {
    if (e.target.closest('button, input, a, select, textarea, label')) return;
    tDrag = { x: e.clientX, y: e.clientY, sx: tc.scrollLeft, sy: tc.scrollTop, moved: false }; tc.classList.add('dragging'); e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => { if (!tDrag) return; const dx = e.clientX - tDrag.x, dy = e.clientY - tDrag.y; if (!tDrag.moved && Math.hypot(dx, dy) > 5) tDrag.moved = true; if (tDrag.moved) { tc.scrollLeft = tDrag.sx - dx; tc.scrollTop = tDrag.sy - dy; } });
  document.addEventListener('mouseup', () => { if (tDrag) { tDrag = null; tc.classList.remove('dragging'); } });

  // wheel zoom（以鼠标位置为中心缩放）
  scroll.addEventListener('wheel', (e) => {
    if (!state.tree) return; e.preventDefault();
    foldNativeScroll();
    let dy = e.deltaY; if (e.deltaMode === 1) dy *= 16; else if (e.deltaMode === 2) dy *= 100;
    if (!dy) return;
    const r = scroll.getBoundingClientRect();
    zoomAt(e.clientX - r.left, e.clientY - r.top, Math.exp(-dy * 0.0015));
  }, { passive: false });
  // pan
  let pan = null;
  scroll.addEventListener('mousedown', (e) => {
    if (!state.tree || e.target.closest('.node')) return;
    foldNativeScroll();
    pan = { x: e.clientX, y: e.clientY, px: state.panX, py: state.panY };
    scroll.style.cursor = 'grabbing'; e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => { if (!pan) return; state.panX = pan.px + (e.clientX - pan.x); state.panY = pan.py + (e.clientY - pan.y); applyZoom(); });
  document.addEventListener('mouseup', () => { if (pan) { pan = null; scroll.style.cursor = ''; } });
  // touch：单指平移 / 双指捏合缩放（捏合开始时记录中点下的内容坐标，
  // 之后每帧用同一锚点换算 pan，保证两指下的内容始终跟随手指）
  const gesture = { g: null };
  const tDist = (e) => Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
  const tMid = (e) => {
    const r = scroll.getBoundingClientRect();
    return { x: (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left, y: (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top };
  };
  const startPan = (t) => ({ mode: 'pan', x: t.clientX, y: t.clientY, px: state.panX, py: state.panY });
  const startPinch = (e) => {
    const m = tMid(e);
    return {
      mode: 'pinch', dist: tDist(e), zoom: state.zoom,
      cx: (m.x - state.panX) / state.zoom, cy: (m.y - state.panY) / state.zoom,
    };
  };
  scroll.addEventListener('touchstart', (e) => {
    if (!state.tree) return;
    foldNativeScroll();
    gesture.g = e.touches.length >= 2 ? startPinch(e) : startPan(e.touches[0]);
  }, { passive: true });
  scroll.addEventListener('touchmove', (e) => {
    if (!gesture.g) return; e.preventDefault();
    const g = gesture.g;
    if (e.touches.length >= 2) {
      if (g.mode !== 'pinch') { gesture.g = startPinch(e); return; }
      const m = tMid(e);
      const nz = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, g.zoom * (tDist(e) / (g.dist || 1))));
      state.zoom = nz;
      state.panX = m.x - g.cx * nz; state.panY = m.y - g.cy * nz;
      applyZoom();
    } else if (e.touches.length === 1) {
      if (g.mode !== 'pan') { gesture.g = startPan(e.touches[0]); return; }
      const t = e.touches[0];
      state.panX = g.px + (t.clientX - g.x); state.panY = g.py + (t.clientY - g.y); applyZoom();
    }
  }, { passive: false });
  scroll.addEventListener('touchend', (e) => {
    if (!gesture.g) return;
    gesture.g = e.touches.length === 1 ? startPan(e.touches[0]) : null;
  });
  scroll.addEventListener('touchcancel', () => { gesture.g = null; });

  document.querySelector('.rate-presets button[data-v="60"]').classList.add('active');
}
wire();
