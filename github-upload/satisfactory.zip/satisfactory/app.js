/* Satisfactory 1.0 产线计算器（结构与交互对齐戴森球计算器） */
'use strict';

const D = window.APP_DATA;
const $ = (id) => document.getElementById(id);
const ZOOM_MIN = 0.05, ZOOM_MAX = 2.5;

// ---- State ----
const state = {
  itemId: null,
  rate: 60,
  useAlt: true,          // 默认允许使用替代配方（具体选用哪个仍可在抽屉/表格中切换）
  treatOreAsRaw: true,
  defaultOc: 100,        // 全局默认超频（%），修改时批量同步到产线所有环节
  recipeChoice: {},      // itemId -> recipeId | '__raw__'
  nodeSettings: {},      // itemId -> { overclock, useSloop }（未设置 = 100% / 不使用索莫晶体）
  hasComputed: false,    // 只有点击「计算产线」后才展示流程
  pickerOpen: false,     // 配方选择抽屉默认收起
  tree: null,
  zoom: 1, panX: 0, panY: 0,
  viewMode: 'tree',
};

// ---- Utilities ----
function fmt(n) {
  if (n === 0) return '0';
  if (Math.abs(n) < 0.001) return n.toExponential(2);
  const r = Math.round(n * 1000) / 1000;
  return Number.isInteger(r) ? r.toString() : r.toFixed(3).replace(/\.?0+$/, '');
}
function itemZh(id) { return D.items[id]?.zh || D.items[id]?.name || id; }
function itemEn(id) { return D.items[id]?.name || id; }
function itemImg(id) { return D.items[id]?.img || ''; }
function isFluid(id) { return !!D.items[id]?.isFluid; }
function itemIsRaw(id) { return D.rawResources.includes(id); }
function buildingInfo(id) {
  return D.buildings[id] || { id, zh: id, name: id, img: '', power: 0, speed: 1, sloopSlots: 0 };
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

/** Return list of recipe objects producing itemId, honoring `useAlt`. */
function recipesForItem(itemId) {
  const ids = D.itemToRecipes[itemId] || [];
  const out = [];
  for (const id of ids) {
    const r = D.recipes[id];
    if (!r) continue;
    if (r.alternate && !state.useAlt) continue;
    out.push(r);
  }
  out.sort((a, b) => (a.alternate !== b.alternate ? (a.alternate ? 1 : -1) : 0));
  return out;
}
function defaultRecipe(itemId) {
  if (itemIsRaw(itemId) && state.treatOreAsRaw) return '__raw__';
  const list = recipesForItem(itemId);
  if (!list.length) return '__raw__';
  return list[0].id;
}

// ---- 产物级超频 / 索莫晶体（像戴森球计算器的增产剂选择一样逐产物可选） ----
const OC_PRESETS = [100, 125, 150, 200, 250];
function clampOc(v) {
  const n = Math.round(parseFloat(v));
  if (!Number.isFinite(n)) return 100;
  return Math.max(1, Math.min(250, n));
}
function getNodeSettings(itemId) {
  return state.nodeSettings[itemId] || { overclock: 100, useSloop: false };
}
function setItemOverclock(itemId, oc) {
  if (!state.nodeSettings[itemId]) state.nodeSettings[itemId] = {};
  state.nodeSettings[itemId].overclock = clampOc(oc);
  recomputeAndRender(true);
}
function setItemSloop(itemId, use) {
  if (!state.nodeSettings[itemId]) state.nodeSettings[itemId] = {};
  state.nodeSettings[itemId].useSloop = !!use;
  recomputeAndRender(true);
}
function buildingFor(itemId) {
  const chosen = state.recipeChoice[itemId] || defaultRecipe(itemId);
  const r = chosen !== '__raw__' ? D.recipes[chosen] : null;
  return r ? buildingInfo(r.producedIn[0]) : null;
}
function canSloop(itemId) {
  const b = buildingFor(itemId);
  return !!(b && b.sloopSlots > 0);
}
function ocSelHTML(itemId, oc, sloopOn) {
  const ocBtns = OC_PRESETS.map(v =>
    `<button type="button" class="ps-btn ps-oc${oc === v ? ' active' : ''}" data-item="${itemId}" data-oc="${v}" title="超频 ${v}%">${v === 100 ? '100%' : v}</button>`).join('');
  const b = buildingFor(itemId);
  const sloopBtn = (b && b.sloopSlots > 0)
    ? `<button type="button" class="ps-btn ps-sloop${sloopOn ? ' active' : ''}" data-item="${itemId}" title="使用索莫晶体 ×${b.sloopSlots}（产出×2 · 功耗×4）">${sloopOn ? '索莫×' + b.sloopSlots : '索莫'}</button>`
    : '';
  return `<span class="oc-sel${(oc !== 100 || sloopOn) ? ' on' : ''}" data-item="${itemId}">${ocBtns}${sloopBtn}</span>`;
}
function handleOcSelClick(btn) {
  const itemId = btn.dataset.item;
  const chosen = state.recipeChoice[itemId] || defaultRecipe(itemId);
  if (chosen === '__raw__') return;
  if (btn.classList.contains('ps-sloop')) {
    if (!canSloop(itemId)) return;
    setItemSloop(itemId, !getNodeSettings(itemId).useSloop);
  } else {
    setItemOverclock(itemId, btn.dataset.oc);
  }
}
function setAllOc(oc) {
  if (!state.hasComputed || !state.tree || state.tree.isRaw) return;
  const seen = new Set();
  (function walk(n) {
    if (seen.has(n.itemId)) return; seen.add(n.itemId);
    if (!n.isRaw && (state.recipeChoice[n.itemId] || defaultRecipe(n.itemId)) !== '__raw__') {
      if (!state.nodeSettings[n.itemId]) state.nodeSettings[n.itemId] = {};
      state.nodeSettings[n.itemId].overclock = clampOc(oc);
    }
    n.children.forEach(walk);
  })(state.tree);
  recomputeAndRender(true);
}
function setAllSloop(use) {
  if (!state.hasComputed || !state.tree || state.tree.isRaw) return;
  const seen = new Set();
  (function walk(n) {
    if (seen.has(n.itemId)) return; seen.add(n.itemId);
    if (!n.isRaw && canSloop(n.itemId)) {
      if (!state.nodeSettings[n.itemId]) state.nodeSettings[n.itemId] = {};
      state.nodeSettings[n.itemId].useSloop = use;
    }
    n.children.forEach(walk);
  })(state.tree);
  recomputeAndRender(true);
}

// ---- Search / Combobox ----
function buildSearchIndex() {
  const items = Object.values(D.items).map(i => ({
    id: i.id, zh: i.zh, en: (i.name || '').toLowerCase(), img: i.img,
  }));
  items.sort((a, b) => a.zh.localeCompare(b.zh, 'zh-Hans-CN'));
  return items;
}
const searchIndex = buildSearchIndex();

function renderDropdown(query) {
  const q = query.trim().toLowerCase();
  const filtered = searchIndex.filter(i => {
    if (!q) return true;
    return i.zh.toLowerCase().includes(q) || i.en.includes(q) || i.id.toLowerCase().includes(q);
  }).slice(0, 80);
  const dd = $('itemDropdown');
  if (!filtered.length) {
    dd.innerHTML = '<div class="drop-item"><span style="color:var(--muted)">无匹配项</span></div>';
  } else {
    dd.innerHTML = filtered.map(i => `
      <div class="drop-item" data-id="${i.id}">
        <img src="${i.img || ''}" alt="" loading="lazy" onerror="this.style.visibility='hidden'"/>
        <span class="zh">${i.zh}</span>
        <button type="button" class="info-btn" data-info="${i.id}" title="查看物品详情">ⓘ</button>
      </div>`).join('');
  }
  dd.classList.remove('hidden');
}
function pickItem(id) {
  state.itemId = id;
  state.recipeChoice = {};
  state.nodeSettings = {};
  state.tree = null;
  state.hasComputed = false;
  const it = D.items[id];
  const el = $('selectedItem');
  el.classList.remove('hidden');
  el.innerHTML = `
    <img src="${it.img || ''}" alt="" onerror="this.style.visibility='hidden'"/>
    <div class="info"><span class="zh">${it.zh}</span></div>
    <button type="button" class="info-btn" data-info="${id}" title="查看物品详情">详情 ⓘ</button>`;
  $('itemSearch').value = it.zh;
  $('itemDropdown').classList.add('hidden');
  $('recipePicker').innerHTML = '';
  $('nodes').innerHTML = ''; $('edges').innerHTML = '';
  resetViewToTree();
  $('summary').textContent = `已选择「${it.zh}」，点击「计算产线」生成流程`;
  showEmpty(`已选择「${escapeHtml(it.zh)}」<br/>点击左侧「计算产线」按钮生成流程图`);
}
function resetViewToTree() {
  state.viewMode = 'tree';
  $('canvasScroll').style.display = '';
  $('tableContainer').style.display = 'none';
  $('tableContainer').innerHTML = '';
  ['zoomOut', 'zoomReset', 'zoomIn'].forEach(id => $(id).style.display = '');
  document.querySelectorAll('.view-btn').forEach(b => b.classList.toggle('active', b.dataset.view === 'tree'));
}

// ---- BOM calculation ----
let nodeCounter = 0;
function calcTree(itemId, rateNeeded, depth = 0, visited = new Set()) {
  const nodeId = 'n' + (nodeCounter++);
  if (visited.has(itemId)) {
    return { id: nodeId, itemId, rateNeeded, recipeId: '__raw__', isRaw: true, children: [], depth };
  }
  const chosen = state.recipeChoice[itemId] || defaultRecipe(itemId);
  if (chosen === '__raw__') {
    return { id: nodeId, itemId, rateNeeded, recipeId: '__raw__', isRaw: true, children: [], depth };
  }
  const r = D.recipes[chosen];
  if (!r) {
    return { id: nodeId, itemId, rateNeeded, recipeId: '__raw__', isRaw: true, children: [], depth };
  }
  const product = r.products.find(p => p.item === itemId) || r.products[0];
  const perMinute = (product.amount * 60) / r.time;
  // Per-item overclock / somersloop
  const settings = getNodeSettings(itemId);
  const overclock = settings.overclock || 100;
  const clockMult = overclock / 100;
  const bId = r.producedIn[0];
  const b = buildingInfo(bId);
  const sloopOn = !!settings.useSloop && b.sloopSlots > 0;
  const sloopMult = sloopOn ? 2 : 1;
  const totalMult = clockMult * sloopMult;
  const machineCount = rateNeeded / (perMinute * totalMult);
  const powerExponent = 1.321928;
  const sloopPowerMult = sloopOn ? 4 : 1;
  const powerPerMachine = b.power > 0 ? b.power * Math.pow(clockMult, powerExponent) * sloopPowerMult : 0;
  const totalPower = powerPerMachine * machineCount;
  const byproducts = r.products
    .filter(p => p.item !== product.item)
    .map(p => {
      const bpPerMin = (p.amount * 60) / r.time;
      const totalBp = bpPerMin * clockMult * sloopMult * machineCount;
      return { item: p.item, rate: totalBp };
    });
  const nextVisited = new Set(visited);
  nextVisited.add(itemId);
  const children = r.ingredients.map(ing => {
    const ingPerMinute = (ing.amount * 60) / r.time;
    const totalIng = ingPerMinute * clockMult * machineCount;
    return calcTree(ing.item, totalIng, depth + 1, nextVisited);
  });
  return {
    id: nodeId, itemId, rateNeeded, recipeId: chosen, isRaw: false,
    machineCount, perMinute, clockMult, sloopMult, sloopOn, sloopSlots: b.sloopSlots,
    overclock, powerPerMachine, totalPower, byproducts, children, depth, buildingId: bId,
  };
}

// ---- Layout ----
function estimateNodeH(n) {
  let h = 252; // 头部 + 设备行 + 超频选择行 + 配方行 + 原料行（近似）
  if (n.byproducts && n.byproducts.length) h += 64;
  return h;
}
function layoutTree(root) {
  const all = [];
  const walk = (n) => { all.push(n); n.children.forEach(walk); };
  walk(root);
  const maxDepth = Math.max(...all.map(n => n.depth));
  for (const n of all) n.col = maxDepth - n.depth;
  const colW = 430, rowH = 320, cardW = 250, cardH = 220;
  let yCursor = 0;
  const yByCol = {};
  function place(n) {
    if (!n.children.length) { n.y = yCursor; yCursor += Math.max(rowH, estimateNodeH(n) + 42); }
    else {
      n.children.forEach(place);
      const ys = n.children.map(c => c.y);
      n.y = (Math.min(...ys) + Math.max(...ys)) / 2;
    }
    const list = (yByCol[n.col] = yByCol[n.col] || []);
    while (true) {
      let push = 0;
      for (const p of list) {
        // 垂直堆叠时按较高一方的高度留出间距，避免高节点（如带副产物）压住下方节点
        const need = Math.max(rowH * 0.85, Math.max(estimateNodeH(n), estimateNodeH(p.n)) + 36);
        const dist = Math.abs(p.y - n.y);
        if (dist < need) push = Math.max(push, need - dist);
      }
      if (!push) break;
      n.y += push + 8;
    }
    list.push({ y: n.y, n });
    n.x = n.col * colW;
  }
  place(root);
  const minY = Math.min(...all.map(n => n.y));
  for (const n of all) n.y -= minY;
  const maxX = Math.max(...all.map(n => n.x)) + cardW;
  const maxY = Math.max(...all.map(n => n.y)) + Math.max(...all.map(n => estimateNodeH(n)));
  return { all, maxX, maxY, colW, rowH, cardW, cardH };
}

// ---- Tree rendering ----
function renderTree(preserveView) {
  const nodesEl = $('nodes'), edgesEl = $('edges'), canvasEl = $('canvas');
  nodesEl.innerHTML = ''; edgesEl.innerHTML = '';
  nodesEl.classList.toggle('animate', !preserveView);
  edgesEl.classList.toggle('animate', !preserveView);
  if (!state.tree) { showEmpty('选择目标产物并计算，产线图会显示在这里。'); return; }
  if (state.tree.isRaw) { showEmpty('该产物当前视为原料终点（直接获取）。<br/>若存在生产配方，可在左下「配方 / 超频 / 索莫晶体 选择」面板中点击配方卡片展开生产链。'); return; }

  $('emptyState').classList.add('hidden');
  const lay = layoutTree(state.tree);
  const pad = 40;
  const contentW = lay.maxX + pad * 2, contentH = lay.maxY + pad * 2;
  canvasEl.style.width = contentW + 'px'; canvasEl.style.height = contentH + 'px';
  state._contentW = contentW; state._contentH = contentH;
  edgesEl.setAttribute('viewBox', `0 0 ${contentW} ${contentH}`);
  edgesEl.setAttribute('preserveAspectRatio', 'none');
  edgesEl.innerHTML = `
    <defs>
      <linearGradient id="edgeGrad" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="${contentW}" y2="0">
        <stop offset="0%" stop-color="#7ed957"/><stop offset="100%" stop-color="#ff9f43"/>
      </linearGradient>
      <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse">
        <path d="M0,0 L10,5 L0,10 z" fill="#ff9f43"/>
      </marker>
    </defs>`;
  for (const n of lay.all) renderNode(n, nodesEl);
  for (const n of lay.all) {
    for (const c of n.children) {
      const childEl = nodesEl.querySelector(`[data-id="${c.id}"]`);
      const parentEl = nodesEl.querySelector(`[data-id="${n.id}"]`);
      const cw = childEl ? childEl.offsetWidth : lay.cardW;
      const ch = childEl ? childEl.offsetHeight : lay.cardH;
      const ph = parentEl ? parentEl.offsetHeight : lay.cardH;
      // 端点贴卡片边缘：起点在子卡片右侧、终点在父卡片左边（箭头可见），y 取卡片垂直中心
      const x1 = c.x + cw + 10, y1 = c.y + ch / 2;
      const x2 = n.x - 4, y2 = n.y + ph / 2;
      const midX = (x1 + x2) / 2;
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('class', 'edge');
      path.setAttribute('d', `M ${x1} ${y1} C ${midX} ${y1}, ${midX} ${y2}, ${x2} ${y2}`);
      path.setAttribute('marker-end', 'url(#arrow)');
      path.setAttribute('pathLength', '1'); // 供描线动画使用
      path.setAttribute('vector-effect', 'non-scaling-stroke'); // 缩放时保持屏幕像素线宽
      if (!preserveView) path.style.animationDelay = Math.min(140 + c.depth * 60, 480) + 'ms';
      path.dataset.from = c.id; path.dataset.to = n.id;
      edgesEl.appendChild(path);
    }
  }
  applyZoom();
  if (!preserveView) requestAnimationFrame(() => fitToView());
}
function showEmpty(msg) {
  const es = $('emptyState');
  es.classList.remove('hidden');
  es.innerHTML = `<div class="hero">◆</div><p>${msg}</p>`;
}
function fitToView() {
  const scroll = $('canvasScroll');
  if (!state._contentW || !state._contentH) return;
  scroll.scrollLeft = 0; scroll.scrollTop = 0; // 清除浏览器恢复的原生滚动，避免整体偏移
  const f = 0.85;
  const vw = Math.max(40, (scroll.clientWidth - 40) * f), vh = Math.max(40, (scroll.clientHeight - 40) * f);
  state.zoom = Math.max(ZOOM_MIN, Math.min(Math.min(vw / state._contentW, vh / state._contentH), 1.5));
  state.panX = Math.max(0, (scroll.clientWidth - state._contentW * state.zoom) / 2);
  state.panY = Math.max(0, (scroll.clientHeight - state._contentH * state.zoom) / 2);
  applyZoom();
}
// 把浏览器恢复/残留的原生滚动偏移折叠进 pan（视觉不变），使坐标始终纯净
function foldNativeScroll() {
  const el = $('canvasScroll');
  if (el.scrollLeft) { state.panX -= el.scrollLeft; el.scrollLeft = 0; }
  if (el.scrollTop) { state.panY -= el.scrollTop; el.scrollTop = 0; }
}
function applyZoom() {
  const scrollEl = $('canvasScroll');
  if (scrollEl.scrollLeft) { state.panX -= scrollEl.scrollLeft; scrollEl.scrollLeft = 0; }
  if (scrollEl.scrollTop) { state.panY -= scrollEl.scrollTop; scrollEl.scrollTop = 0; }
  $('canvas').style.transform = `translate(${state.panX}px, ${state.panY}px) scale(${state.zoom})`;
  $('zoomReset').textContent = Math.round(state.zoom * 100) + '%';
}
// 以 (mx,my)（相对画布容器）为中心缩放：保持该点内容在屏幕上不动
function zoomAt(mx, my, ratio) {
  const old = state.zoom;
  const nz = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, old * ratio));
  if (nz === old) return;
  const cx = (mx - state.panX) / old, cy = (my - state.panY) / old;
  state.zoom = nz; state.panX = mx - cx * nz; state.panY = my - cy * nz;
  applyZoom();
}

function renderNode(n, container) {
  const el = document.createElement('div');
  const r = n.isRaw ? null : D.recipes[n.recipeId];
  el.className = 'node' + (n.isRaw ? ' raw' : '') + (r && r.alternate ? ' alt-recipe' : '');
  el.style.left = n.x + 'px'; el.style.top = n.y + 'px';
  el.style.animationDelay = Math.min(n.depth * 55, 330) + 'ms';
  el.dataset.id = n.id;
  const it = D.items[n.itemId] || { zh: n.itemId, name: n.itemId, img: '' };
  const rateStr = fmt(n.rateNeeded) + ' / min' + (isFluid(n.itemId) ? '（m³）' : '');

  let bodyHTML = '';
  if (n.isRaw) {
    bodyHTML = `
      <div class="machine-line">
        <img src="${sourceIcon(n.itemId)}" alt="" data-imgid="${n.itemId}" onerror="this.style.visibility='hidden'"/>
        <div class="info">
          <div class="name">原材料</div>
          <div class="sub">${itemIsRaw(n.itemId) ? '直接开采/抽取' : '视为原料终点'}</div>
        </div>
        <div class="count">${fmt(n.rateNeeded)} /min</div>
      </div>`;
  } else {
    const b = buildingInfo(n.buildingId);
    const effPerMin = n.perMinute * n.clockMult * n.sloopMult;
    const powerStr = n.powerPerMachine > 0 ? fmt(n.powerPerMachine) + ' MW' : '变量功率';
    const ocBadge = n.overclock !== 100 ? `<span class="oc-badge">超频 ${n.overclock}%</span>` : '';
    const sloopBadge = n.sloopOn ? `<span class="sloop-badge">索莫 ×${n.sloopSlots}</span>` : '';
    bodyHTML = `
      <div class="machine-line">
        <img src="${b.img || ''}" alt="" data-imgid="${n.buildingId}" onerror="this.style.visibility='hidden'"/>
        <div class="info">
          <div class="name">${b.zh}</div>
          <div class="sub">${fmt(effPerMin)} /min · ${powerStr}</div>
        </div>
        <div class="count">×${fmt(n.machineCount)}</div>
      </div>
      <div class="node-badges">${ocBadge}${sloopBadge}${ocSelHTML(n.itemId, n.overclock, n.sloopOn)}</div>
      <div class="node-recipe ${r.alternate ? 'alt' : ''}">
        ${r.alternate ? '替代配方 · ' : '配方 · '}${escapeHtml(r.zh)}
        <span class="change" data-changeitem="${n.itemId}">切换 ⇋</span>
      </div>
      <div class="node-ings">
        ${r.ingredients.map(ing => {
          const perMin = (ing.amount * 60 / r.time) * n.clockMult * n.machineCount;
          return `<div class="ing-chip" data-info="${ing.item}" title="查看物品详情">
            <img src="${itemImg(ing.item)}" alt="" data-imgid="${ing.item}" onerror="this.style.visibility='hidden'"/>
            <span>${itemZh(ing.item)}</span>
            <span class="amt">${fmt(perMin)}</span>
          </div>`;
        }).join('')}
      </div>
      ${n.byproducts && n.byproducts.length ? `
      <div class="node-byproducts">
        <div class="bp-label">副产物</div>
        <div class="bp-chips">
          ${n.byproducts.map(bp => `
          <div class="byproduct-chip" data-info="${bp.item}" title="查看物品详情">
            <img src="${itemImg(bp.item)}" alt="" data-imgid="${bp.item}" onerror="this.style.visibility='hidden'"/>
            <span>${itemZh(bp.item)}</span>
            <span class="amt">${fmt(bp.rate)}</span>
          </div>`).join('')}
        </div>
      </div>` : ''}`;
  }

  el.innerHTML = `
    <div class="node-head" data-info="${n.itemId}" title="查看物品详情">
      <img class="p-img" src="${it.img || ''}" alt="" data-imgid="${n.itemId}" onerror="this.style.visibility='hidden'"/>
      <div class="p-info">
        <div class="p-zh">${it.zh}</div>
        <div class="p-rate">${rateStr}</div>
      </div>
    </div>
    <div class="node-body">${bodyHTML}</div>`;

  el.addEventListener('mouseenter', () => {
    document.querySelectorAll('.edge').forEach(p => {
      if (p.dataset.from === n.id || p.dataset.to === n.id) p.classList.add('hi');
    });
  });
  el.addEventListener('mouseleave', () => {
    document.querySelectorAll('.edge').forEach(p => p.classList.remove('hi'));
  });
  container.appendChild(el);

  el.querySelectorAll('.change[data-changeitem]').forEach(sp => {
    sp.addEventListener('click', () => {
      setPickerExpanded(true); // 面板折叠时先展开
      setTimeout(() => {
        const g = document.querySelector(`.picker-group[data-item="${sp.dataset.changeitem}"]`);
        if (g) { g.scrollIntoView({ behavior: 'smooth', block: 'center' }); g.style.outline = '2px solid var(--accent)'; setTimeout(() => g.style.outline = '', 1500); }
      }, 80);
    });
  });
}

function sourceIcon(itemId) {
  const map = {
    Desc_Water_C: 'Desc_WaterPump_C',
    Desc_LiquidOil_C: 'Desc_OilPump_C',
    Desc_NitrogenGas_C: 'Desc_FrackingSmasher_C',
    Desc_OreIron_C: 'Desc_MinerMk1_C',
    Desc_OreCopper_C: 'Desc_MinerMk1_C',
    Desc_Coal_C: 'Desc_MinerMk1_C',
    Desc_OreGold_C: 'Desc_MinerMk1_C',
    Desc_Stone_C: 'Desc_MinerMk1_C',
    Desc_Sulfur_C: 'Desc_MinerMk1_C',
    Desc_OreBauxite_C: 'Desc_MinerMk1_C',
    Desc_OreUranium_C: 'Desc_MinerMk1_C',
    Desc_RawQuartz_C: 'Desc_MinerMk1_C',
    Desc_SAM_C: 'Desc_MinerMk1_C',
  };
  const bId = map[itemId];
  if (bId) return D.buildings[bId]?.img || itemImg(itemId);
  return itemImg(itemId);
}

function placeholderSrc(id) {
  const it = D.items[id];
  const label = (it && it.zh) ? it.zh : String(id || '?');
  const ch = Array.from(label)[0] || '?';
  const colors = ['#ff9f43', '#22d18e', '#7aa2ff', '#ff6b6b', '#c084fc', '#22d3ee'];
  let h = 7;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  const c = colors[h % colors.length];
  const cv = document.createElement('canvas');
  cv.width = 64; cv.height = 64;
  const ctx = cv.getContext('2d');
  ctx.fillStyle = 'rgba(255,255,255,0.06)';
  ctx.fillRect(0, 0, 64, 64);
  ctx.fillStyle = c;
  ctx.beginPath();
  ctx.arc(32, 32, 24, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#0b1220';
  ctx.font = 'bold 26px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(ch, 32, 33);
  return cv.toDataURL('image/png');
}

// ---- Table view（仿戴森球计算器统计表：每行一个物品，行内切换配方 / 超频 / 索莫晶体） ----
function computeAggregates() {
  const rawTot = {}, machineTot = {}, byproductTot = {};
  let totalPower = 0, sloopCnt = 0, ocCnt = 0;
  (function walk(n) {
    if (n.isRaw) { rawTot[n.itemId] = (rawTot[n.itemId] || 0) + n.rateNeeded; }
    else {
      machineTot[n.buildingId] = (machineTot[n.buildingId] || 0) + n.machineCount;
      totalPower += n.totalPower || 0;
      if (n.sloopOn) sloopCnt += n.sloopSlots * n.machineCount;
      if (n.overclock !== 100) ocCnt++;
      if (n.byproducts) for (const bp of n.byproducts) byproductTot[bp.item] = (byproductTot[bp.item] || 0) + bp.rate;
      n.children.forEach(walk);
    }
  })(state.tree);
  return { rawTot, machineTot, byproductTot, totalPower, sloopCnt, ocCnt };
}
function renderTableView() {
  const container = $('tableContainer');
  const prevScroll = { x: container.scrollLeft, y: container.scrollTop };
  container.innerHTML = '';
  if (!state.tree) { container.innerHTML = '<p class="table-empty">请选择产物并计算。</p>'; return; }
  if (state.tree.isRaw) { container.innerHTML = '<p class="table-empty">该产物当前视为原料终点（直接获取）。<br/>若存在生产配方，可在左下「配方 / 超频 / 索莫晶体 选择」面板中点击配方卡片展开生产链。</p>'; return; }

  const agg = computeAggregates();
  const it0 = D.items[state.itemId];
  const machineStr = Object.entries(agg.machineTot).map(([b, c]) => `<span class="t2-stat-chip"><img src="${buildingInfo(b).img || ''}" alt="" data-imgid="${b}" onerror="this.style.visibility='hidden'"/>${buildingInfo(b).zh}×${fmt(c)}</span>`).join('');
  const rawStr = Object.entries(agg.rawTot).map(([id, r]) => `<span class="t2-stat-chip" data-info="${id}" title="查看物品详情"><img src="${itemImg(id)}" alt="" data-imgid="${id}" onerror="this.style.visibility='hidden'"/>${itemZh(id)} ${fmt(r)}/min</span>`).join('');
  const bpStr = Object.entries(agg.byproductTot).map(([id, r]) => `<span class="t2-stat-chip" data-info="${id}" title="查看物品详情"><img src="${itemImg(id)}" alt="" data-imgid="${id}" onerror="this.style.visibility='hidden'"/>${itemZh(id)} ${fmt(r)}/min</span>`).join('');
  const stats = document.createElement('div'); stats.className = 't2-stats';
  stats.innerHTML = `
    <div class="t2-stat final"><span class="k">目标产物</span><span class="v" data-info="${state.itemId}" title="查看物品详情"><img src="${it0.img || ''}" alt="" data-imgid="${state.itemId}" onerror="this.style.visibility='hidden'"/>${it0.zh} ${fmt(state.rate)}/min</span></div>
    <div class="t2-stat"><span class="k">建筑统计</span><span class="v">${machineStr || '-'}</span></div>
    <div class="t2-stat"><span class="k">原料输入</span><span class="v">${rawStr || '-'}</span></div>
    ${agg.totalPower > 0 ? `<div class="t2-stat"><span class="k">预估电力</span><span class="v">${fmt(agg.totalPower)} MW</span></div>` : ''}
    ${agg.ocCnt > 0 ? `<div class="t2-stat"><span class="k">超频环节</span><span class="v">${agg.ocCnt} 处</span></div>` : ''}
    ${agg.sloopCnt > 0 ? `<div class="t2-stat alt"><span class="k">索莫晶体</span><span class="v">${fmt(agg.sloopCnt)} 个</span></div>` : ''}
    ${bpStr ? `<div class="t2-stat alt"><span class="k">副产物</span><span class="v">${bpStr}</span></div>` : ''}`;

  // 行 = 树中物品去重（首次出现 = 最浅层），目标产物排最前
  const seen = new Map();
  (function walk(n) { if (!seen.has(n.itemId)) seen.set(n.itemId, n); n.children.forEach(walk); })(state.tree);
  const rows = [...seen.values()].sort((a, b) => (a.itemId === state.itemId ? -1 : b.itemId === state.itemId ? 1 : a.depth - b.depth));

  const table = document.createElement('table'); table.className = 't2-table';
  table.innerHTML = `<thead><tr><th class="t2-op">操作</th><th>物品 / 产能</th><th>工厂</th><th class="t2-recipes">配方选取（点击切换）</th><th class="t2-oc">超频 / 索莫晶体</th></tr></thead>`;
  const tbody = document.createElement('tbody');
  for (const n of rows) tbody.appendChild(buildTableRow(n));
  table.appendChild(tbody);
  container.appendChild(stats);
  container.appendChild(table);
  container.scrollTo(prevScroll.x, prevScroll.y);
}
function buildTableRow(n) {
  const tr = document.createElement('tr');
  const it = D.items[n.itemId] || { zh: n.itemId, img: '' };
  const isFinal = n.itemId === state.itemId;
  // 操作列：原矿可切换「视为原料 / 展开生产」
  let opHTML = '';
  if (itemIsRaw(n.itemId) && recipesForItem(n.itemId).length) {
    const asRaw = (state.recipeChoice[n.itemId] || defaultRecipe(n.itemId)) === '__raw__';
    opHTML = `<button type="button" class="t2-raw-toggle${asRaw ? ' active' : ''}" data-item="${n.itemId}" title="在「视为原料终点」与「展开生产链」之间切换">${asRaw ? '已视为原料' : '展开生产'}</button>`;
  } else if (isFinal) {
    opHTML = '<span class="t2-final-badge">目标</span>';
  }
  // 物品 / 产能
  const bypHTML = (n.byproducts && n.byproducts.length) ? `<div class="t2-byp">副产：${n.byproducts.map(bp => `${itemZh(bp.item)} +${fmt(bp.rate)}/min`).join('、')}</div>` : '';
  const rateHTML = `<div class="t2-rate">${fmt(n.rateNeeded)}/min${isFluid(n.itemId) ? '（m³）' : ''}</div>`;
  // 工厂
  let facHTML = '';
  if (n.isRaw) {
    const bId = sourceIconBuilding(n.itemId);
    const b = bId ? D.buildings[bId] : null;
    facHTML = `<div class="t2-fac"><img src="${b ? b.img : itemImg(n.itemId)}" alt="" title="${b ? b.zh : '直接获取'}" onerror="this.style.visibility='hidden'"/><span class="t2-fac-src">${b ? b.zh : '直接获取'}</span></div>`;
  } else {
    const b = buildingInfo(n.buildingId);
    facHTML = `<div class="t2-fac"><img src="${b.img || ''}" alt="" title="${b.zh}" onerror="this.style.visibility='hidden'"/><b>×${fmt(n.machineCount)}</b><span class="t2-fac-name">${b.zh}</span></div>`;
  }
  // 配方选取
  const recHTML = n.isRaw
    ? (recipesForItem(n.itemId).length
      ? recipesForItem(n.itemId).map(r => recipeCardHTML(n.itemId, r, n.recipeId === r.id)).join('')
      : '<div class="t2-no-recipe">直接获取</div>')
    : (recipesForItem(n.itemId).length
      ? recipesForItem(n.itemId).map(r => recipeCardHTML(n.itemId, r, n.recipeId === r.id)).join('')
      : '<div class="t2-no-recipe">无可用配方（可勾选「允许使用替代配方」）</div>');
  // 超频 / 索莫晶体
  const s = getNodeSettings(n.itemId);
  const ocHTML = n.isRaw ? '<span class="t2-none">—</span>' : ocSelHTML(n.itemId, s.overclock || 100, !!s.useSloop);
  tr.innerHTML = `
    <td class="t2-op">${opHTML}</td>
    <td><div class="t2-item"><img src="${it.img || ''}" alt="" title="查看物品详情" data-info="${n.itemId}" data-imgid="${n.itemId}" onerror="this.style.visibility='hidden'"/><div><div class="t2-name${isFinal ? ' final' : ''}" data-info="${n.itemId}" title="查看物品详情">${it.zh}</div><div class="t2-en">${escapeHtml(it.name || '')}</div>${rateHTML}${bypHTML}</div></div></td>
    <td>${facHTML}</td>
    <td class="t2-recipes"><div class="t2-recipe-list">${recHTML}</div></td>
    <td class="t2-oc">${ocHTML}</td>`;
  return tr;
}
function sourceIconBuilding(itemId) {
  const map = {
    Desc_Water_C: 'Desc_WaterPump_C',
    Desc_LiquidOil_C: 'Desc_OilPump_C',
    Desc_NitrogenGas_C: 'Desc_FrackingSmasher_C',
    Desc_OreIron_C: 'Desc_MinerMk1_C', Desc_OreCopper_C: 'Desc_MinerMk1_C',
    Desc_Coal_C: 'Desc_MinerMk1_C', Desc_OreGold_C: 'Desc_MinerMk1_C',
    Desc_Stone_C: 'Desc_MinerMk1_C', Desc_Sulfur_C: 'Desc_MinerMk1_C',
    Desc_OreBauxite_C: 'Desc_MinerMk1_C', Desc_OreUranium_C: 'Desc_MinerMk1_C',
    Desc_RawQuartz_C: 'Desc_MinerMk1_C', Desc_SAM_C: 'Desc_MinerMk1_C',
  };
  return map[itemId] || null;
}
// ---- Recipe card（仿 dsp-calc.pro 配方卡片） ----
function recipeCardHTML(itemId, r, active) {
  const b = buildingInfo(r.producedIn[0]);
  const ins = r.ingredients.map(i => `<span class="rc-chip"><img src="${itemImg(i.item)}" alt="" title="${itemZh(i.item)}" onerror="this.style.visibility='hidden'"/><b>×${fmt(i.amount)}</b></span>`).join('');
  const outs = r.products.map(p => `<span class="rc-chip out${p.item === itemId ? ' main' : ''}"><img src="${itemImg(p.item)}" alt="" title="${itemZh(p.item)}" onerror="this.style.visibility='hidden'"/><b>×${fmt(p.amount)}</b></span>`).join('');
  return `<div class="recipe-card${active ? ' active' : ''}" data-item="${itemId}" data-recipe="${r.id}" role="button" title="点击选用此配方">
    <div class="rc-flow">${ins}<span class="rc-arrow">→</span>${outs}</div>
    <div class="rc-meta">${escapeHtml(b.zh)} · ${r.time}s${r.alternate ? '<span class="rc-badge alt">替代</span>' : ''}</div>
  </div>`;
}

// ---- Recipe picker（抽屉面板：配方 / 超频 / 索莫晶体 逐产物选择） ----
function setPickerExpanded(exp) {
  state.pickerOpen = exp;
  $('pickerDrawer').classList.toggle('open', exp);
  $('pickerToggle').classList.toggle('active', exp);
}
function updatePickerLabel(count) {
  $('pickerCount').textContent = count ? `共 ${count} 项` : '';
  $('pickerBadge').textContent = count ? String(count) : '';
}
function renderRecipePicker() {
  const holder = $('recipePicker');
  const prevScroll = holder.scrollTop;
  holder.innerHTML = '';
  if (!state.tree) { updatePickerLabel(0); return; }
  const seen = new Set(); const rows = [];
  (function walk(n) { if (!seen.has(n.itemId)) { seen.add(n.itemId); rows.push(n); } n.children.forEach(walk); })(state.tree);
  let groupCount = 0;
  for (const n of rows) {
    const itemId = n.itemId;
    const list = recipesForItem(itemId);
    const isRaw = itemIsRaw(itemId);
    if (!list.length && !isRaw) continue;
    groupCount++;
    const currentChoice = state.recipeChoice[itemId] || defaultRecipe(itemId);
    const group = document.createElement('div');
    group.className = 'picker-group'; group.dataset.item = itemId;
    const it = D.items[itemId] || {};
    group.innerHTML = `<div class="head" data-info="${itemId}" title="查看物品详情"><img src="${it.img || ''}" alt="" onerror="this.style.visibility='hidden'"/><span class="zh">${it.zh || itemId}</span><span class="rate">${fmt(n.rateNeeded)}/min</span></div><div class="opts"></div>`;
    const opts = group.querySelector('.opts');
    if (isRaw) {
      opts.insertAdjacentHTML('beforeend', `<div class="recipe-card raw${currentChoice === '__raw__' ? ' active' : ''}" data-item="${itemId}" data-recipe="__raw__" role="button" title="点击后该物品视为原料终点，不再展开生产链"><div class="rc-meta">直接获取 / 视为原料终点</div></div>`);
    }
    for (const r of list) {
      opts.insertAdjacentHTML('beforeend', recipeCardHTML(itemId, r, currentChoice === r.id));
    }
    // 超频 / 索莫晶体控件（仅对有配方的环节显示）
    if (currentChoice !== '__raw__' && D.recipes[currentChoice]) {
      const s = getNodeSettings(itemId);
      const ctrl = document.createElement('div'); ctrl.className = 'picker-controls';
      ctrl.innerHTML = `
        <div class="pc-oc"><span class="pc-lbl">超频</span>${ocSelHTML(itemId, s.overclock || 100, !!s.useSloop)}</div>
        <div class="pc-oc"><span class="pc-lbl">自定义</span><input type="number" class="oc-input" min="1" max="250" step="1" value="${s.overclock || 100}" data-item="${itemId}"/><span class="oc-unit">%（1–250）</span></div>`;
      group.appendChild(ctrl);
    }
    holder.appendChild(group);
  }
  holder.scrollTop = prevScroll;
  updatePickerLabel(groupCount);
}

// ---- Main ----
function recomputeAndRender(preserveView) {
  if (!state.hasComputed || !state.itemId || !state.rate) return;
  nodeCounter = 0;
  state.tree = calcTree(state.itemId, state.rate);
  if (state.viewMode === 'table') renderTableView(); else renderTree(preserveView);
  renderRecipePicker();
  renderSummary();
  // 目标产物默认视为原料终点时，自动展开配方面板方便选择生产配方
  if (state.tree && state.tree.isRaw && recipesForItem(state.itemId).length) setPickerExpanded(true);
}
function renderSummary() {
  if (!state.tree) { $('summary').textContent = '请选择产物并点击「计算产线」'; return; }
  if (state.tree.isRaw) { $('summary').textContent = '该产物视为原料终点，可在下方配方面板选择生产配方'; return; }
  const agg = computeAggregates();
  const it = D.items[state.itemId];
  const machineStr = Object.entries(agg.machineTot).map(([b, c]) => `${buildingInfo(b).zh}×${fmt(c)}`).join('，');
  const rawStr = Object.entries(agg.rawTot).map(([id, r]) => `${itemZh(id)} ${fmt(r)}/min`).join('，');
  const bpStr = Object.entries(agg.byproductTot).map(([id, r]) => `${itemZh(id)} ${fmt(r)}/min`).join('，');
  const parts = [
    `<strong>${it.zh}</strong> ${fmt(state.rate)}/min`,
    `机器：${machineStr || '-'}`,
    `原料：${rawStr || '-'}`,
  ];
  if (agg.totalPower > 0) parts.push(`功率：${fmt(agg.totalPower)} MW`);
  if (agg.ocCnt > 0) parts.push(`超频：${agg.ocCnt} 处`);
  if (agg.sloopCnt > 0) parts.push(`索莫晶体：${fmt(agg.sloopCnt)} 个`);
  if (bpStr) parts.push(`副产物：${bpStr}`);
  $('summary').innerHTML = parts.join(' | ');
}

// ---- View switching ----
function switchView(mode) {
  state.viewMode = mode;
  const isTree = mode === 'tree';
  $('canvasScroll').style.display = isTree ? '' : 'none';
  $('tableContainer').style.display = isTree ? 'none' : '';
  ['zoomOut', 'zoomReset', 'zoomIn'].forEach(id => $(id).style.display = isTree ? '' : 'none');
  document.querySelectorAll('.view-btn').forEach(b => b.classList.toggle('active', b.dataset.view === mode));
  if (isTree) renderTree(false); else renderTableView();
}

// ---- Export PNG（戴森球计算器同款：等待真实图标加载，逐级回退保证导出可用） ----
// 等待克隆节点中的图片全部加载完成；仅加载失败的图片才退回首字占位图
function waitImagesLoaded(elm) {
  const imgs = [...elm.querySelectorAll('img')];
  return Promise.all(imgs.map(img => {
    if (img.complete && img.naturalWidth > 0) return Promise.resolve();
    return new Promise(res => {
      img.addEventListener('load', res, { once: true });
      img.addEventListener('error', res, { once: true });
      setTimeout(res, 5000); // 兜底超时，避免个别图片阻塞导出
    });
  }));
}

/** 把克隆节点内的图片内联为 data URL（同源 fetch），失败时回退首字母占位 */
const _imgCache = {};
async function inlineImages(elm) {
  const imgs = Array.from(elm.querySelectorAll('img'));
  await Promise.all(imgs.map(async (img) => {
    const src = img.getAttribute('src');
    if (!src || src.startsWith('data:')) return;
    let dataUrl = _imgCache[src];
    if (dataUrl === undefined) {
      dataUrl = null;
      try {
        const resp = await fetch(src);
        if (resp.ok) {
          const blob = await resp.blob();
          dataUrl = await new Promise((resolve) => {
            const fr = new FileReader();
            fr.onload = () => resolve(fr.result);
            fr.onerror = () => resolve(null);
            fr.readAsDataURL(blob);
          });
        }
      } catch (err) { dataUrl = null; }
      _imgCache[src] = dataUrl;
    }
    if (dataUrl) img.src = dataUrl;
    else if (img.dataset.imgid) img.src = placeholderSrc(img.dataset.imgid);
  }));
  await waitImagesLoaded(elm);
}

function toPngBlob(canvas) {
  return new Promise((resolve, reject) => {
    try { canvas.toBlob(b => b ? resolve(b) : reject(new Error('empty-blob')), 'image/png'); }
    catch (err) { reject(err); } // SecurityError：画布被图片污染（file:// 场景）
  });
}
async function renderHtml2Canvas(elm, w, h, label) {
  if (!window.html2canvas) { alert('导出组件未加载，请刷新页面后重试。'); return; }
  elm.style.position = 'fixed'; elm.style.left = '-20000px'; elm.style.top = '0'; elm.style.zIndex = '-1';
  elm.style.width = w + 'px'; elm.style.height = h + 'px'; elm.style.margin = '0'; elm.style.background = '#0a1120';
  document.body.appendChild(elm);
  try {
    const opts = { backgroundColor: '#0a1120', useCORS: true, allowTaint: false, logging: false,
      scale: Math.min(2, Math.max(1, 6000 / Math.max(w, h))) };
    await waitImagesLoaded(elm);
    let canvas, blob;
    if (location.protocol === 'file:') {
      // file:// 下 fetch 可能被禁：先逐张尝试内联（成功→真实图标，失败→该图占位），避免导出空白
      await inlineImages(elm);
      canvas = await html2canvas(elm, opts);
      blob = await toPngBlob(canvas).catch(() => null);
    } else {
      // http(s) 下同源图标可直接渲染导出
      canvas = await html2canvas(elm, opts);
      blob = await toPngBlob(canvas).catch(() => null);
      if (!blob) {
        // 画布被污染：内联真实图标后重渲染
        await inlineImages(elm);
        canvas = await html2canvas(elm, opts);
        blob = await toPngBlob(canvas).catch(() => null);
      }
    }
    if (!blob) {
      // 最终兜底：全部退回首字占位图，保证导出可用
      elm.querySelectorAll('img').forEach(img => { const id = img.dataset.imgid; if (id) img.src = placeholderSrc(id); });
      await new Promise(r => setTimeout(r, 80));
      canvas = await html2canvas(elm, opts);
      blob = await toPngBlob(canvas);
    }
    const a = document.createElement('a'); const it = D.items[state.itemId];
    a.download = `${it?.zh || 'production'}-${state.rate}pmin-${label}.png`;
    a.href = URL.createObjectURL(blob); a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  } finally { elm.remove(); }
}
async function exportPng() {
  if (!state.tree) { alert('请先计算产线'); return; }
  if (state.viewMode === 'table') {
    const wrap = $('tableContainer');
    if (!wrap.querySelector('.t2-table')) return;
    const clone = wrap.cloneNode(true); clone.style.width = wrap.scrollWidth + 'px';
    clone.querySelectorAll('.oc-sel:not(.on)').forEach(el => el.remove());
    killAnimations(clone);
    await renderHtml2Canvas(clone, wrap.scrollWidth, wrap.scrollHeight, 'table'); return;
  }
  const canvasEl = $('canvas'); const w = canvasEl.offsetWidth, h = canvasEl.offsetHeight;
  const clone = canvasEl.cloneNode(true); clone.style.transform = 'none'; clone.style.position = 'relative';
  clone.style.left = '0'; clone.style.top = '0';
  clone.querySelectorAll('.oc-sel:not(.on)').forEach(el => el.remove());
  // 固定入场动画的最终状态，避免导出瞬间节点/连线处于透明起始帧
  clone.querySelectorAll('.nodes, .edges').forEach(el => el.classList.remove('animate'));
  clone.querySelectorAll('.node, .edge').forEach(el => { el.style.animation = 'none'; el.style.opacity = ''; });
  killAnimations(clone);
  await renderHtml2Canvas(clone, w, h, 'tree');
}
/** 导出前禁用 CSS 动画，避免 html2canvas 捕获到动画起始帧（opacity:0） */
function killAnimations(elm) {
  elm.classList.add('export-static');
  elm.style.animation = 'none';
  elm.querySelectorAll('*').forEach(e => { e.style.animation = 'none'; });
}

// ---- Item details modal（物品介绍 / 来源 / 生产流程 / 用途，戴森球计算器同款） ----
const usageIndex = {};
for (const r of Object.values(D.recipes)) {
  for (const ing of r.ingredients) (usageIndex[ing.item] = usageIndex[ing.item] || []).push(r.id);
}
const RAW_BUILDING_DESC = {
  Desc_MinerMk1_C: '地表矿脉，使用采掘机开采',
  Desc_WaterPump_C: '开阔水域，使用抽水站抽取',
  Desc_OilPump_C: '油井，使用油气抽取机抽取',
  Desc_FrackingSmasher_C: '加压井眼，使用爆破钻机开采',
};
// 弹窗内的配方列表不跟随「允许使用替代配方」开关（信息展示应完整）
function allRecipesForItem(itemId) {
  const ids = D.itemToRecipes[itemId] || [];
  const out = [];
  for (const id of ids) { const r = D.recipes[id]; if (r) out.push(r); }
  out.sort((a, b) => (a.alternate !== b.alternate ? (a.alternate ? 1 : -1) : 0));
  return out;
}
function infoChipHTML(itemId, amount, hl) {
  return `<span class="info-chip${hl ? ' hl' : ''}" data-info="${itemId}" title="查看物品详情">
    <img src="${itemImg(itemId)}" alt="" onerror="this.style.visibility='hidden'"/>
    <span>${itemZh(itemId)}</span>${amount != null ? `<b>×${fmt(amount)}</b>` : ''}</span>`;
}
function recipeRowHTML(r, highlightItem) {
  const b = buildingInfo(r.producedIn[0]);
  const ins = r.ingredients.map(i => infoChipHTML(i.item, i.amount, i.item === highlightItem)).join('');
  const outs = r.products.map(p => infoChipHTML(p.item, p.amount, p.item === highlightItem)).join('');
  const badges = r.alternate ? '<span class="ri-badge alt">替代</span>' : '';
  return `<div class="info-recipe">
    <div class="ir-head">
      <img src="${b.img || ''}" alt="" onerror="this.style.visibility='hidden'"/>
      <span class="ir-name">${escapeHtml(r.zh)}</span>
      <span class="ir-machine">${escapeHtml(b.zh)}</span>
      <span class="ir-time">${r.time}s</span>
      ${badges}
    </div>
    <div class="ir-flow">${ins}<span class="ir-arrow">→</span>${outs}</div>
  </div>`;
}
function openInfo(itemId) {
  const it = D.items[itemId];
  if (!it) return;
  $('itemDropdown').classList.add('hidden');
  const img = $('infoImg');
  img.src = it.img || ''; img.style.visibility = it.img ? 'visible' : 'hidden';
  $('infoName').textContent = it.zh;
  const subBits = [it.name];
  if (isFluid(itemId)) subBits.push('流体（m³）');
  else if (it.stackSize) subBits.push('堆叠 ×' + it.stackSize);
  $('infoSub').textContent = subBits.join(' · ');
  $('infoWiki').href = 'https://satisfactory-calculator.com/zh/items/detail/id/' + itemId + '/name/' + encodeURIComponent(it.zh || it.name || '');

  const srcB = sourceIconBuilding(itemId);
  const srcHTML = [];
  if (itemIsRaw(itemId)) {
    srcHTML.push(`<div class="info-src">
      <img src="${srcB && D.buildings[srcB] ? D.buildings[srcB].img : itemImg(itemId)}" alt="" onerror="this.style.visibility='hidden'"/>
      <div><div class="src-name">${srcB && D.buildings[srcB] ? D.buildings[srcB].zh : '直接获取'} · 自然资源</div>
      <div class="src-desc">${escapeHtml(RAW_BUILDING_DESC[srcB] || '直接开采/抽取的基础资源')}</div></div></div>`);
  } else {
    srcHTML.push(`<div class="info-src"><div><div class="src-name">合成产物</div>
      <div class="src-desc">由生产设备制造，见下方「生产流程」</div></div></div>`);
  }
  const produces = allRecipesForItem(itemId);
  const uses = (usageIndex[itemId] || []).map(id => D.recipes[id]).filter(Boolean);
  const prodHTML = produces.length ? produces.map(r => recipeRowHTML(r, itemId)).join('') : '<p class="info-none">无合成配方（直接获取）</p>';
  const useHTML = uses.length ? uses.map(r => recipeRowHTML(r, itemId)).join('') : '<p class="info-none">暂无下游配方使用该物品</p>';
  $('infoBody').innerHTML = `
    <div class="info-sec"><div class="info-sec-title">介绍</div>
      <p class="info-desc">${it.desc ? escapeHtml(it.desc).replace(/\n/g, '<br/>') : '暂无介绍，可点击右上角前往详情页查看。'}</p></div>
    <div class="info-sec"><div class="info-sec-title">来源</div>${srcHTML.join('')}</div>
    <div class="info-sec"><div class="info-sec-title">生产流程<span class="sec-count">${produces.length} 个配方</span></div>${prodHTML}</div>
    <div class="info-sec"><div class="info-sec-title">用途<span class="sec-count">${uses.length} 个配方</span></div>${useHTML}</div>`;
  $('infoModal').classList.remove('hidden');
}
function closeInfo() { $('infoModal').classList.add('hidden'); }

// ---- Wiring ----
function wire() {
  const scroll = $('canvasScroll');
  const search = $('itemSearch');
  search.addEventListener('focus', () => renderDropdown(search.value));
  search.addEventListener('input', () => renderDropdown(search.value));
  document.addEventListener('click', (e) => { if (!e.target.closest('.combo')) $('itemDropdown').classList.add('hidden'); });
  $('itemDropdown').addEventListener('click', (e) => {
    if (e.target.closest('[data-info]')) return; // ⓘ 按钮：查看详情，不选择物品
    const it = e.target.closest('.drop-item');
    if (it && it.dataset.id) pickItem(it.dataset.id);
  });
  $('rateInput').addEventListener('input', (e) => {
    state.rate = parseFloat(e.target.value) || 0;
    document.querySelectorAll('.rate-presets button').forEach(b => b.classList.toggle('active', parseFloat(b.dataset.v) === state.rate));
  });
  document.querySelectorAll('.rate-presets button').forEach(b => b.addEventListener('click', () => {
    state.rate = parseFloat(b.dataset.v); $('rateInput').value = state.rate;
    document.querySelectorAll('.rate-presets button').forEach(x => x.classList.toggle('active', x === b));
  }));
  $('useAlt').addEventListener('change', (e) => { state.useAlt = e.target.checked; state.recipeChoice = {}; recomputeAndRender(); });
  $('treatOreAsRaw').addEventListener('change', (e) => { state.treatOreAsRaw = e.target.checked; state.recipeChoice = {}; recomputeAndRender(); });
  $('ocDefault').addEventListener('change', (e) => {
    state.defaultOc = parseInt(e.target.value, 10) || 100;
    setAllOc(state.defaultOc); // 批量同步到产线所有环节
  });
  $('sloopAll').addEventListener('click', () => setAllSloop(true));
  $('sloopNone').addEventListener('click', () => setAllSloop(false));
  $('calcBtn').addEventListener('click', () => {
    if (!state.itemId) { alert('请先选择产物'); $('itemSearch').focus(); return; }
    if (!state.rate || state.rate <= 0) { alert('请输入有效的每分钟产量'); return; }
    state.hasComputed = true;
    recomputeAndRender();
  });
  document.querySelectorAll('.view-btn').forEach(btn => btn.addEventListener('click', () => {
    if (!state.hasComputed) return;
    switchView(btn.dataset.view);
  }));
  $('zoomIn').addEventListener('click', () => zoomAt(scroll.clientWidth / 2, scroll.clientHeight / 2, 1.25));
  $('zoomOut').addEventListener('click', () => zoomAt(scroll.clientWidth / 2, scroll.clientHeight / 2, 1 / 1.25));
  $('zoomReset').addEventListener('click', () => fitToView());
  $('exportPng').addEventListener('click', exportPng);

  // 超频/索莫选择 / 配方卡片 / 原矿切换（全局事件委托）
  document.addEventListener('click', (e) => {
    const ps = e.target.closest('.ps-btn');
    if (ps) { if (state.hasComputed) handleOcSelClick(ps); return; }
    const card = e.target.closest('.recipe-card');
    if (card) {
      const itemId = card.dataset.item, rid = card.dataset.recipe;
      if (!itemId || !rid || !state.hasComputed) return;
      if (state.recipeChoice[itemId] !== rid) {
        state.recipeChoice[itemId] = rid;
        recomputeAndRender(true);
      }
      return;
    }
    const rawT = e.target.closest('.t2-raw-toggle');
    if (rawT) {
      const itemId = rawT.dataset.item;
      const cur = state.recipeChoice[itemId] || defaultRecipe(itemId);
      if (cur === '__raw__') { const first = recipesForItem(itemId)[0]; if (first) state.recipeChoice[itemId] = first.id; }
      else state.recipeChoice[itemId] = '__raw__';
      recomputeAndRender(true); return;
    }
    const infoEl = e.target.closest('[data-info]');
    if (infoEl && infoEl.dataset.info) openInfo(infoEl.dataset.info);
  });
  document.addEventListener('change', (e) => {
    const inp = e.target.closest('.oc-input[data-item]');
    if (inp) setItemOverclock(inp.dataset.item, inp.value);
  });
  $('pickerToggle').addEventListener('click', () => setPickerExpanded(!state.pickerOpen));
  $('drawerClose').addEventListener('click', () => setPickerExpanded(false));
  setPickerExpanded(false);
  $('infoClose').addEventListener('click', closeInfo);
  $('infoMask').addEventListener('click', closeInfo);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeInfo(); setPickerExpanded(false); } });

  // sidebar drag-to-scroll
  const sidebar = document.querySelector('.controls');
  const getScrollEl = () => { const p = $('recipePicker'); return (p && state.pickerOpen && p.scrollHeight > p.clientHeight) ? p : sidebar; };
  let sDrag = null, sWasDrag = false;
  sidebar.addEventListener('mousedown', (e) => {
    if (e.target.closest('input, button, select, textarea')) return;
    const el = getScrollEl(); sDrag = { y: e.clientY, top: el.scrollTop, el, moved: false }; sWasDrag = false;
  });
  document.addEventListener('mousemove', (e) => {
    if (!sDrag) return; const dy = e.clientY - sDrag.y;
    if (!sDrag.moved && Math.abs(dy) > 5) { sDrag.moved = true; sWasDrag = true; sidebar.classList.add('dragging'); }
    if (sDrag.moved) { sDrag.el.scrollTop = sDrag.top - dy; e.preventDefault(); }
  });
  document.addEventListener('mouseup', () => { if (sDrag) { sDrag = null; sidebar.classList.remove('dragging'); } });
  sidebar.addEventListener('click', (e) => { if (sWasDrag) { sWasDrag = false; e.preventDefault(); e.stopPropagation(); } }, true);

  // table drag
  const tc = $('tableContainer'); let tDrag = null;
  tc.addEventListener('mousedown', (e) => {
    if (e.target.closest('button, input, a, select, textarea, label')) return;
    tDrag = { x: e.clientX, y: e.clientY, sx: tc.scrollLeft, sy: tc.scrollTop, moved: false }; tc.classList.add('dragging'); e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => { if (!tDrag) return; const dx = e.clientX - tDrag.x, dy = e.clientY - tDrag.y; if (!tDrag.moved && Math.hypot(dx, dy) > 5) tDrag.moved = true; if (tDrag.moved) { tc.scrollLeft = tDrag.sx - dx; tc.scrollTop = tDrag.sy - dy; } });
  document.addEventListener('mouseup', () => { if (tDrag) { tDrag = null; tc.classList.remove('dragging'); } });

  // wheel zoom（以鼠标位置为中心缩放）
  scroll.addEventListener('wheel', (e) => {
    if (!state.tree) return; e.preventDefault();
    foldNativeScroll();
    let dy = e.deltaY; if (e.deltaMode === 1) dy *= 16; else if (e.deltaMode === 2) dy *= 100;
    if (!dy) return;
    const r = scroll.getBoundingClientRect();
    zoomAt(e.clientX - r.left, e.clientY - r.top, Math.exp(-dy * 0.0015));
  }, { passive: false });
  // pan
  let pan = null;
  scroll.addEventListener('mousedown', (e) => {
    if (!state.tree || e.target.closest('.node')) return;
    foldNativeScroll();
    pan = { x: e.clientX, y: e.clientY, px: state.panX, py: state.panY };
    scroll.style.cursor = 'grabbing'; e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => { if (!pan) return; state.panX = pan.px + (e.clientX - pan.x); state.panY = pan.py + (e.clientY - pan.y); applyZoom(); });
  document.addEventListener('mouseup', () => { if (pan) { pan = null; scroll.style.cursor = ''; } });
  // touch：单指平移 / 双指捏合缩放（捏合开始时记录中点下的内容坐标，
  // 之后每帧用同一锚点换算 pan，保证两指下的内容始终跟随手指）
  const gesture = { g: null };
  const tDist = (e) => Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
  const tMid = (e) => {
    const r = scroll.getBoundingClientRect();
    return { x: (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left, y: (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top };
  };
  const startPan = (t) => ({ mode: 'pan', x: t.clientX, y: t.clientY, px: state.panX, py: state.panY });
  const startPinch = (e) => {
    const m = tMid(e);
    return {
      mode: 'pinch', dist: tDist(e), zoom: state.zoom,
      cx: (m.x - state.panX) / state.zoom, cy: (m.y - state.panY) / state.zoom,
    };
  };
  scroll.addEventListener('touchstart', (e) => {
    if (!state.tree) return;
    foldNativeScroll();
    gesture.g = e.touches.length >= 2 ? startPinch(e) : startPan(e.touches[0]);
  }, { passive: true });
  scroll.addEventListener('touchmove', (e) => {
    if (!gesture.g) return; e.preventDefault();
    const g = gesture.g;
    if (e.touches.length >= 2) {
      if (g.mode !== 'pinch') { gesture.g = startPinch(e); return; }
      const m = tMid(e);
      const nz = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, g.zoom * (tDist(e) / (g.dist || 1))));
      state.zoom = nz;
      state.panX = m.x - g.cx * nz; state.panY = m.y - g.cy * nz;
      applyZoom();
    } else if (e.touches.length === 1) {
      if (g.mode !== 'pan') { gesture.g = startPan(e.touches[0]); return; }
      const t = e.touches[0];
      state.panX = g.px + (t.clientX - g.x); state.panY = g.py + (t.clientY - g.y); applyZoom();
    }
  }, { passive: false });
  scroll.addEventListener('touchend', (e) => {
    if (!gesture.g) return;
    gesture.g = e.touches.length === 1 ? startPan(e.touches[0]) : null;
  });
  scroll.addEventListener('touchcancel', () => { gesture.g = null; });

  document.querySelector('.rate-presets button[data-v="60"]').classList.add('active');
}
// ---- 启动自检：部署混版 / 数据损坏时给出明确提示，而不是静默失效 ----
function bootFatal(title, detail) {
  const bar = document.createElement('div');
  bar.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9999;background:#b91c1c;color:#fff;padding:10px 16px;font-size:13px;line-height:1.7;box-shadow:0 4px 16px rgba(0,0,0,.4)';
  bar.innerHTML = `<strong>⚠ ${title}</strong><br/><span style="opacity:.92">${detail}</span>`;
  document.body.appendChild(bar);
  console.error('[幸福工厂计算器]', title, detail);
}
function boot() {
  try {
    // 1) index.html 与脚本版本是否匹配（浏览器缓存旧页面时在此暴露）
    const EXPECT_VER = 'v10';
    if (window.APP_VERSION !== EXPECT_VER) {
      bootFatal('页面文件版本不一致（页面：' + (window.APP_VERSION || '未知') + ' / 脚本：' + EXPECT_VER + '）',
        '浏览器缓存了旧版 index.html。请按 Ctrl+F5（Mac：Cmd+Shift+R）强制刷新；手机浏览器在菜单里选「刷新/清除缓存」。Docker 部署请确认已用 --build 重建镜像。');
      return;
    }
    // 2) 数据文件完整性（上传截断 / 漏传时在此暴露）
    const d = window.APP_DATA;
    const dataOk = !!(d && d.items && Object.keys(d.items).length > 50 && d.recipes && Object.keys(d.recipes).length > 50);
    if (!dataOk) {
      bootFatal('数据文件 data.js 缺失或损坏',
        '请重新上传 app/data.js（约 3.2 MB，注意传输不要截断），建议使用部署包 zip 整体解压后重建镜像。');
      return;
    }
    // 3) 新版页面结构完整性（index.html 与 app.js 新旧混放时在此暴露）
    const missing = ['pickerToggle', 'pickerDrawer', 'infoModal', 'ocDefault'].filter(id => !document.getElementById(id));
    if (missing.length) {
      bootFatal('页面结构不完整', '缺少元素：' + missing.join('、') + '。index.html 与 app.js 新旧版本混放，请整体重新部署全部文件后强制刷新。');
      return;
    }
    wire();
  } catch (err) {
    bootFatal('初始化失败', String((err && err.message) || err));
  }
}
boot();
